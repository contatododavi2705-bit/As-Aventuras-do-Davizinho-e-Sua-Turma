@echo off
setlocal

if "%GDK%"=="" (
    echo ERRO: configure a variavel de ambiente GDK para a pasta do SGDK.
    exit /b 1
)

if not exist "%GDK%\bin\make.exe" (
    echo ERRO: make.exe nao encontrado em "%GDK%\bin".
    exit /b 1
)

if not exist "res\sprites\davi.png" (
    echo Gerando assets...
    python tools\gerar_assets.py
    if errorlevel 1 (
        echo ERRO: falha ao gerar assets. Instale Python 3 e Pillow: pip install pillow
        exit /b 1
    )
)

if /I "%1"=="clean" (
    "%GDK%\bin\make.exe" -f "%GDK%\makefile.gen" clean
    exit /b %errorlevel%
)

"%GDK%\bin\make.exe" -f "%GDK%\makefile.gen"
if errorlevel 1 (
    echo ERRO: compilacao falhou.
    exit /b 1
)

if exist "out\rom.bin" (
    echo Compilacao concluida: out\rom.bin
) else (
    echo AVISO: out\rom.bin nao foi encontrado. Verifique a saida do make.
    exit /b 1
)
endlocal

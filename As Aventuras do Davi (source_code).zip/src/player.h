#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "game.h"
#include "collision.h"

typedef enum { PS_NORMAL, PS_HURT, PS_DEAD, PS_WIN } PlayerState;

typedef struct
{
    Body        b;
    Sprite     *spr;
    u8          anim;
    bool        faceLeft;
    bool        jumping;
    PlayerState state;
    u8          health;
    u16         inv;            /* quadros de invulnerabilidade restantes */
    u16         timer;          /* quadros no estado atual (morte/vitoria) */
    u8          hurtTimer;
    u8          coyote;
    u8          jumpBuf;
    s16         cpX, cpY;       /* checkpoint: centro x e pe y em pixels */
} Player;

extern Player gPlayer;

void player_create(void);
void player_setStart(u8 cx, u8 cy);
void player_respawn(void);
void player_update(void);
void player_draw(void);
void player_hurt(void);
void player_kill(void);
void player_win(void);
void player_bounce(void);
void projectile_update(void);

#endif

#include "game.h"
#include "menus.h"

/*
 * Campanha: Titulo -> (Novo Jogo | Selecionar Fase) -> Fase 1..5 -> Final -> Creditos -> opcoes.
 * Cada fase termina somente ao tocar a bandeira (player_win -> RES_COMPLETE).
 */
static void playCampaign(u8 lvl)
{
    while (TRUE)
    {
        LevelResult r;

        menus_levelIntro(lvl);
        do { r = game_playLevel(lvl); } while (r == RES_RESTART);

        if (r == RES_GAMEOVER)
        {
            if (menus_gameOver() == 0) { game_retry(); continue; }    /* tentar novamente a mesma fase */
            return;                                                    /* voltar ao menu */
        }

        /* fase concluida: libera a proxima */
        if (lvl + 1 < NUM_LEVELS && lvl + 1 > gGame.unlocked) gGame.unlocked = lvl + 1;

        if (lvl >= NUM_LEVELS - 1)
        {
            menus_ending();
            menus_credits();
            if (menus_endChoice() == 1) { game_newGame(); lvl = 0; continue; }   /* jogar novamente */
            return;                                                              /* titulo */
        }
        menus_levelComplete(lvl);
        lvl++;
    }
}

int main(bool hardReset)
{
    game_init();

    while (TRUE)
    {
        u8 choice = menus_title();
        u8 lvl = 0;

        game_newGame();
        if (choice == 1) lvl = menus_levelSelect();
        playCampaign(lvl);
    }
    return 0;
}

#ifndef _LEVELS_H_
#define _LEVELS_H_

#include "game.h"

#define MAX_MAP_CELLS   2400

extern u8 lvMap[MAX_MAP_CELLS];     /* mapa de celulas 16x16, indexado por y*lvW+x */
extern u8 lvW, lvH;                 /* tamanho do mapa em celulas */

/* tipos de tile (indice do metatile em res/tiles/terrain.png) */
enum
{
    TL_EMPTY, TL_GRASS, TL_DIRT, TL_STONE, TL_WOOD, TL_SPIKE, TL_BUSH, TL_FLOWER,
    TL_TRUNK, TL_LEAFPLAT, TL_FENCE, TL_BENCH, TL_TOY, TL_SIGN, TL_BARK, TL_CANOPY
};

/* tipos de objeto que uma fase pode posicionar */
enum
{
    SP_START, SP_COIN, SP_HEART, SP_LIFE, SP_CHECK, SP_GOAL, SP_NPC, SP_WALKER, SP_FLYER
};

typedef struct { u8 x0, x1, top; } Span;                 /* chao: grama em 'top', terra abaixo */
typedef struct { u8 x, y, w, h, tile; } Block;           /* retangulo de tiles */
typedef struct { u8 type, x, y, n; } Spawn;              /* objeto (celula x,y; n = quantidade/argumento) */

typedef struct
{
    const char  *name;
    u8           w, h;
    u8           theme;
    const Span  *spans;   u8 nSpans;
    const Block *blocks;  u8 nBlocks;
    const Spawn *spawns;  u8 nSpawns;
    void       (*extra)(void);      /* construtor procedural opcional */
} LevelDef;

typedef struct { u8 who; const char *text; } Dialog;   /* who: 0 Agata, 1 Maria F., 2 Maxwell, 3 Miguel */

extern const LevelDef gLevels[NUM_LEVELS];
extern const Dialog   gDialogs[16];

void       levels_load(u8 idx);
u8         levels_tile(s16 cx, s16 cy);
const u16 *levels_palTerrain(u8 theme);
const u16 *levels_palBg(u8 theme);

#endif

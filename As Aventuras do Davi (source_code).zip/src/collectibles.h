#ifndef _COLLECTIBLES_H_
#define _COLLECTIBLES_H_

#include "game.h"

extern const char *gDialogue;       /* fala da Turma proxima ao Davi (ou NULL) */

void items_reset(void);
void items_add(u8 type, u8 cx, u8 cy, u8 n);   /* type = SP_COIN, SP_HEART, SP_LIFE, SP_CHECK, SP_GOAL, SP_NPC */
void items_update(void);

#endif

#include "collision.h"
#include "levels.h"

/* classe de colisao de cada tipo de tile do mapa (ver enum em levels.h) */
static const u8 tileClass[16] =
{
    T_NONE,     /* 0 vazio        */
    T_SOLID,    /* 1 grama        */
    T_SOLID,    /* 2 terra        */
    T_SOLID,    /* 3 pedra        */
    T_ONEWAY,   /* 4 madeira      */
    T_HAZARD,   /* 5 espinhos     */
    T_NONE,     /* 6 arbusto      */
    T_NONE,     /* 7 flores       */
    T_NONE,     /* 8 tronco       */
    T_ONEWAY,   /* 9 folhagem     */
    T_NONE,     /* 10 cerca       */
    T_NONE,     /* 11 banco       */
    T_SOLID,    /* 12 brinquedo   */
    T_NONE,     /* 13 placa       */
    T_SOLID,    /* 14 casca       */
    T_NONE      /* 15 copa        */
};

u8 col_class(s16 px, s16 py)
{
    if (px < 0 || px >= (s16)(lvW * CELL)) return T_SOLID;      /* paredes laterais */
    if (py < 0 || py >= (s16)(lvH * CELL)) return T_NONE;
    return tileClass[lvMap[(py >> 4) * lvW + (px >> 4)] & 15];
}

void col_moveX(Body *b)
{
    b->wall = FALSE;
    if (b->vx == 0) return;

    s32 nx = b->x + b->vx;
    s16 top = (s16)(b->y >> 8) - b->h;
    s16 bot = (s16)(b->y >> 8) - 1;
    s16 probe = (b->vx > 0) ? (s16)((nx >> 8) + b->hw - 1) : (s16)((nx >> 8) - b->hw);
    s16 yy = top;
    bool hit = FALSE;

    while (TRUE)
    {
        if (col_class(probe, yy) == T_SOLID) { hit = TRUE; break; }
        if (yy >= bot) break;
        yy += 8;
        if (yy > bot) yy = bot;
    }

    if (hit)
    {
        if (b->vx > 0) b->x = ((s32)(((probe >> 4) << 4) - b->hw)) << 8;
        else           b->x = ((s32)((((probe >> 4) + 1) << 4) + b->hw)) << 8;
        b->vx = 0;
        b->wall = TRUE;
    }
    else b->x = nx;
}

void col_moveY(Body *b)
{
    s32 ny = b->y + b->vy;
    s16 left = (s16)(b->x >> 8) - b->hw;
    s16 right = (s16)(b->x >> 8) + b->hw - 1;
    s16 mid = (left + right) >> 1;
    s16 xs[3];
    u8 i;

    xs[0] = left; xs[1] = mid; xs[2] = right;
    b->ground = FALSE;

    if (b->vy >= 0)
    {
        s16 feet = (s16)((ny + 255) >> 8) - 1;                 /* ultimo pixel ocupado */
        s16 prevFeet = (s16)((b->y + 255) >> 8);                /* borda inferior anterior */
        for (i = 0; i < 3; i++)
        {
            u8 c = col_class(xs[i], feet);
            s16 cellTop = (feet >> 4) << 4;
            if (c == T_SOLID || (c == T_ONEWAY && prevFeet <= cellTop))
            {
                b->y = ((s32)cellTop) << 8;
                b->vy = 0;
                b->ground = TRUE;
                return;
            }
        }
        b->y = ny;
    }
    else
    {
        s16 head = (s16)(ny >> 8) - b->h;
        for (i = 0; i < 3; i++)
        {
            if (col_class(xs[i], head) == T_SOLID)
            {
                b->y = ((s32)((((head >> 4) + 1) << 4) + b->h)) << 8;
                b->vy = 0;
                return;
            }
        }
        b->y = ny;
    }
}

bool col_hazard(const Body *b)
{
    s16 py = (s16)(b->y >> 8) - 3;
    s16 cx = (s16)(b->x >> 8);

    if (py < 0) return FALSE;
    if ((py & 15) < 6) return FALSE;      /* so a metade de baixo do tile machuca */
    if (col_class(cx - b->hw + 2, py) == T_HAZARD) return TRUE;
    if (col_class(cx, py) == T_HAZARD) return TRUE;
    if (col_class(cx + b->hw - 3, py) == T_HAZARD) return TRUE;
    return FALSE;
}

bool col_groundAhead(const Body *b, s16 dir)
{
    s16 px = (s16)(b->x >> 8) + dir * (b->hw + 2);
    s16 py = (s16)(b->y >> 8) + 2;
    u8 c = col_class(px, py);
    return (c == T_SOLID || c == T_ONEWAY);
}

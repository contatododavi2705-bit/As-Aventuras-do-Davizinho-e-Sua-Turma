#include "enemies.h"
#include "collision.h"
#include "player.h"
#include "levels.h"

#define MAX_ENEMIES 24
#define WALK_SPEED  100

typedef struct
{
    u8      type;
    bool    alive;
    Body    b;
    s8      dir;
    s16     baseX;
    s32     baseY;
    s16     amp;
    u16     ang;
    Sprite *spr;
} Enemy;

static Enemy en[MAX_ENEMIES];
static u8 numEnemies;

void enemies_reset(void)
{
    numEnemies = 0;
}

void enemies_add(u8 type, u8 cx, u8 cy, u8 n)
{
    Enemy *e;
    if (numEnemies >= MAX_ENEMIES) return;
    e = &en[numEnemies++];
    e->type = type;
    e->alive = TRUE;
    e->spr = NULL;
    e->b.x = ((s32)(cx * CELL + CELL / 2)) << 8;
    e->b.y = ((s32)((cy + 1) * CELL)) << 8;
    e->b.vx = 0; e->b.vy = 0;
    e->b.hw = 6; e->b.h = 14;
    e->b.ground = FALSE; e->b.wall = FALSE;
    e->dir = (cx & 1) ? 1 : -1;
    e->baseX = cx * CELL + CELL / 2;
    e->baseY = e->b.y;
    e->amp = (n ? n : 2) * CELL;
    e->ang = (cx * 37) & 1023;
}

static void kill(Enemy *e)
{
    e->alive = FALSE;
    if (e->spr) { SPR_releaseSprite(e->spr); e->spr = NULL; }
}

bool enemies_hitPoint(s16 x, s16 y)
{
    u8 i;
    for (i = 0; i < numEnemies; i++)
    {
        Enemy *e = &en[i];
        s16 ex, ey, dx;
        if (!e->alive) continue;
        ex = (s16)(e->b.x >> 8);
        ey = (s16)(e->b.y >> 8);
        dx = x - ex;
        if (dx < 0) dx = -dx;
        if (dx < 10 && y >= ey - 16 && y <= ey)
        {
            kill(e);
            game_addScore(50);
            game_playSfx(SFX_STOMP);
            return TRUE;
        }
    }
    return FALSE;
}

void enemies_update(void)
{
    Player *p = &gPlayer;
    u8 i;

    for (i = 0; i < numEnemies; i++)
    {
        Enemy *e = &en[i];
        s16 ex, ey, dx, dy;
        bool active;

        if (!e->alive) continue;

        ex = (s16)(e->b.x >> 8);
        ey = (s16)(e->b.y >> 8);
        dx = ex - (gCamX + SCREEN_W / 2);
        dy = ey - (gCamY + SCREEN_H / 2);
        active = (dx > -230 && dx < 230 && dy > -190 && dy < 190);

        if (!active)
        {
            if (e->spr) { SPR_releaseSprite(e->spr); e->spr = NULL; }
            continue;
        }
        if (!e->spr)
        {
            e->spr = SPR_addSprite(&spr_enemies, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE));
            if (e->spr) SPR_setAnim(e->spr, e->type);
        }

        /* movimento */
        if (e->type == 0)
        {
            e->b.vx = e->dir * WALK_SPEED;
            e->b.vy += 72;
            if (e->b.vy > 1200) e->b.vy = 1200;
            col_moveX(&e->b);
            col_moveY(&e->b);
            if (e->b.wall) e->dir = -e->dir;
            else if (e->b.ground && !col_groundAhead(&e->b, e->dir)) e->dir = -e->dir;
            if ((e->b.y >> 8) > (s32)(lvH * CELL + 64)) { kill(e); continue; }
        }
        else
        {
            e->ang = (e->ang + 6) & 1023;
            e->b.x = ((s32)e->baseX << 8) + (((s32)sinFix16(e->ang) * e->amp) >> 2);
            e->b.y = e->baseY + (((s32)sinFix16((e->ang * 2) & 1023) * 12) >> 2);   /* +-12 px, sem deriva */
        }

        ex = (s16)(e->b.x >> 8);
        ey = (s16)(e->b.y >> 8);

        /* colisao com o Davi */
        if (p->state == PS_NORMAL || p->state == PS_HURT)
        {
            s16 px = (s16)(p->b.x >> 8);
            s16 py = (s16)(p->b.y >> 8);
            if (px + 4 > ex - 6 && px - 4 < ex + 6 && py > ey - 14 && py - 24 < ey)
            {
                if (p->b.vy > 0 && py <= ey - 4)
                {
                    kill(e);
                    game_addScore(100);
                    game_playSfx(SFX_STOMP);
                    player_bounce();
                    continue;
                }
                else if (p->inv == 0)
                {
                    bool face = p->faceLeft;
                    p->faceLeft = (ex < px);        /* empurrao para longe do inimigo */
                    player_hurt();
                    p->faceLeft = face;
                }
            }
        }

        if (e->spr)
        {
            SPR_setPosition(e->spr, ex - 8 - gCamX, ey - 16 - gCamY);
            SPR_setHFlip(e->spr, (e->type == 0) ? (e->dir < 0) : (cosFix16(e->ang) < 0));
        }
    }
}

#ifdef DAVI_TEST
/* gancho usado apenas pelos testes automatizados (compilado com -DDAVI_TEST) */
bool enemies_ahead(s16 x, s16 y, s16 dir, s16 range, s16 *dist)
{
    u8 i;
    for (i = 0; i < numEnemies; i++)
    {
        s16 ex, ey, d;
        if (!en[i].alive) continue;
        ex = (s16)(en[i].b.x >> 8);
        ey = (s16)(en[i].b.y >> 8);
        d = (ex - x) * dir;
        if (d > 0 && d < range && ey - y < 24 && y - ey < 24) { *dist = d; return TRUE; }
    }
    return FALSE;
}
#endif

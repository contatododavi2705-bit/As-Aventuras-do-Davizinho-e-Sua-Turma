#ifndef _MENUS_H_
#define _MENUS_H_

#include "game.h"

u8   menus_title(void);             /* 0 = novo jogo, 1 = selecionar fase */
u8   menus_levelSelect(void);       /* indice da fase escolhida (so fases liberadas) */
void menus_levelIntro(u8 idx);      /* cartao de apresentacao da fase */
void menus_levelComplete(u8 idx);   /* "FASE CONCLUIDA!" */
u8   menus_gameOver(void);          /* 0 = tentar novamente, 1 = voltar ao menu */
void menus_ending(void);            /* cena de encerramento + PARABENS */
void menus_credits(void);           /* creditos */
u8   menus_endChoice(void);         /* 0 = voltar ao titulo, 1 = jogar novamente */

#endif

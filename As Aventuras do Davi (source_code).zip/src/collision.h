#ifndef _COLLISION_H_
#define _COLLISION_H_

#include "game.h"

#define T_NONE      0
#define T_SOLID     1
#define T_ONEWAY    2
#define T_HAZARD    3

/* Corpo fisico. x,y em 1/256 de pixel; x = centro, y = pe (borda inferior). */
typedef struct
{
    s32  x;
    s32  y;
    s16  vx;
    s16  vy;
    s16  hw;        /* meia largura em pixels */
    s16  h;         /* altura em pixels */
    bool ground;
    bool wall;
} Body;

u8   col_class(s16 px, s16 py);
void col_moveX(Body *b);
void col_moveY(Body *b);
bool col_hazard(const Body *b);
bool col_groundAhead(const Body *b, s16 dir);

#endif

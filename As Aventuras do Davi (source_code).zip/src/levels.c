#include "levels.h"
#include "player.h"
#include "enemies.h"
#include "collectibles.h"

u8 lvMap[MAX_MAP_CELLS];
u8 lvW, lvH;

/* ------------------------------------------------------------------------
   Paletas por tema (0 Mangueiras, 1 Praca, 2 Grande Mangueira, 3 Parquinho, 4 Final)
   indices do terreno: 0 ceu, 1 contorno, 2/3 grama, 4/5 terra, 6/7 madeira,
   8/9 folhas, 10/11 pedra, 12 vermelho, 13 amarelo, 14 azul, 15 branco
   ------------------------------------------------------------------------ */
static const u16 palTerrain[5][16] =
{
    { C3(3,5,7), C3(1,0,1), C3(3,6,1), C3(1,4,1), C3(6,4,2), C3(4,2,1), C3(7,5,2), C3(4,2,1),
      C3(2,6,2), C3(1,4,1), C3(5,5,6), C3(3,3,4), C3(7,1,1), C3(7,7,1), C3(1,3,7), C3(7,7,7) },
    { C3(5,6,7), C3(1,0,1), C3(4,6,1), C3(2,4,1), C3(6,4,3), C3(4,3,2), C3(6,4,2), C3(3,2,1),
      C3(3,6,2), C3(1,4,1), C3(6,6,6), C3(4,4,5), C3(7,2,1), C3(7,7,2), C3(2,3,7), C3(7,7,7) },
    { C3(2,4,5), C3(0,0,1), C3(2,5,2), C3(1,3,1), C3(4,3,2), C3(2,1,1), C3(5,3,1), C3(3,1,0),
      C3(1,5,1), C3(0,3,1), C3(4,4,5), C3(2,2,3), C3(7,1,1), C3(7,7,1), C3(1,3,7), C3(7,7,7) },
    { C3(4,6,7), C3(1,0,2), C3(3,7,2), C3(1,5,1), C3(7,5,3), C3(5,3,2), C3(7,5,2), C3(4,2,1),
      C3(3,7,3), C3(1,5,1), C3(6,6,7), C3(4,4,6), C3(7,1,2), C3(7,7,0), C3(0,4,7), C3(7,7,7) },
    { C3(7,4,3), C3(2,0,2), C3(3,5,1), C3(1,3,1), C3(5,3,2), C3(3,1,1), C3(6,3,1), C3(3,1,0),
      C3(2,5,1), C3(1,3,1), C3(5,4,5), C3(3,2,4), C3(7,1,1), C3(7,7,1), C3(2,2,7), C3(7,7,7) }
};

/* fundo: 1 colinas, 2 colinas escuras, 3 nuvem, 4 sombra da nuvem */
static const u16 palBg[5][16] =
{
    { 0, C3(2,5,3), C3(1,4,2), C3(7,7,7), C3(6,6,7), C3(0,1,3), C3(0,0,1) },
    { 0, C3(3,5,4), C3(2,4,3), C3(7,7,7), C3(7,6,6), C3(0,1,3), C3(0,0,1) },
    { 0, C3(1,4,3), C3(0,3,2), C3(5,7,6), C3(4,6,5), C3(0,1,3), C3(0,0,1) },
    { 0, C3(3,5,6), C3(2,4,5), C3(7,7,7), C3(6,6,7), C3(0,1,3), C3(0,0,1) },
    { 0, C3(4,2,4), C3(3,1,3), C3(7,5,5), C3(6,3,4), C3(0,1,3), C3(0,0,1) }
};

const u16 *levels_palTerrain(u8 theme) { return palTerrain[theme % 5]; }
const u16 *levels_palBg(u8 theme)      { return palBg[theme % 5]; }

/* ------------------------------------------------------------------------
   Falas da Turma (usam apenas ASCII por limitacao da fonte padrao do SGDK)
   ------------------------------------------------------------------------ */
const Dialog gDialogs[16] =
{
    { 3, "MIGUEL: PULE NAS PLATAFORMAS, DAVI!" },
    { 0, "AGATA: JUNTE AS MOEDAS DE OURO!" },
    { 2, "MAXWELL: CUIDADO COM OS BICHINHOS!" },
    { 1, "MARIA F.: A PRACA ESTA LINDA!" },
    { 2, "MAXWELL: APERTE A PARA LANCAR ESTRELAS!" },
    { 0, "AGATA: CUIDADO COM OS ESPINHOS!" },
    { 3, "MIGUEL: SUBA PELA GRANDE MANGUEIRA!" },
    { 1, "MARIA F.: PULE ENTRE OS GALHOS!" },
    { 2, "MAXWELL: LA EM CIMA TEM A BANDEIRA!" },
    { 0, "AGATA: VAMOS BRINCAR NO PARQUINHO!" },
    { 3, "MIGUEL: OLHA OS BLOCOS DE BRINQUEDO!" },
    { 1, "MARIA F.: ALCANCE A BANDEIRA, DAVI!" },
    { 2, "MAXWELL: A AVENTURA FINAL COMECOU!" },
    { 0, "AGATA: A TURMA TORCE POR VOCE!" },
    { 3, "MIGUEL: FALTA POUCO, DAVI!" },
    { 1, "MARIA F.: VOCE E O MAIOR HEROI!" }
};

/* ------------------------------------------------------------------------
   Fase 1 - Bairro das Mangueiras (100 x 14)
   ------------------------------------------------------------------------ */
static const Span sp1[] = { {0,23,11}, {26,45,11}, {48,68,11}, {71,99,11} };
static const Block bl1[] =
{
    /* plataformas */
    {12,9,4,1,TL_WOOD}, {17,7,3,1,TL_WOOD}, {30,9,3,1,TL_WOOD}, {35,7,3,1,TL_WOOD},
    {53,9,4,1,TL_WOOD}, {78,9,3,1,TL_WOOD}, {83,7,4,1,TL_WOOD},
    /* degraus de pedra */
    {58,10,2,1,TL_STONE}, {60,9,2,2,TL_STONE},
    /* mangueiras */
    {5,9,1,2,TL_TRUNK},  {4,7,3,2,TL_CANOPY},  {42,9,1,2,TL_TRUNK}, {41,7,3,2,TL_CANOPY},
    {66,9,1,2,TL_TRUNK}, {65,7,3,2,TL_CANOPY}, {93,9,1,2,TL_TRUNK}, {92,7,3,2,TL_CANOPY},
    /* decoracao */
    {10,10,1,1,TL_BUSH}, {28,10,1,1,TL_BUSH}, {50,10,1,1,TL_BUSH}, {74,10,1,1,TL_BUSH}, {88,10,1,1,TL_BUSH},
    {20,10,1,1,TL_FLOWER}, {38,10,1,1,TL_FLOWER}, {45,10,1,1,TL_FLOWER}, {56,10,1,1,TL_FLOWER},
    {70,10,1,1,TL_FLOWER}, {91,10,1,1,TL_FLOWER}, {1,10,1,1,TL_SIGN}, {94,10,1,1,TL_SIGN}
};
static const Spawn ss1[] =
{
    {SP_START,2,10,0}, {SP_NPC,8,10,0}, {SP_NPC,95,10,1},
    {SP_COIN,9,9,4}, {SP_COIN,13,6,4}, {SP_COIN,18,4,3}, {SP_COIN,23,8,3}, {SP_COIN,31,6,3},
    {SP_COIN,36,4,3}, {SP_COIN,39,9,4}, {SP_COIN,46,8,2}, {SP_COIN,54,6,4}, {SP_COIN,63,9,3},
    {SP_COIN,72,9,3}, {SP_COIN,79,6,3}, {SP_COIN,84,4,4}, {SP_COIN,88,9,3},
    {SP_HEART,86,5,1}, {SP_LIFE,60,7,1},
    {SP_CHECK,49,10,0}, {SP_GOAL,97,10,0},
    {SP_WALKER,18,10,0}, {SP_WALKER,34,10,0}, {SP_WALKER,41,10,0}, {SP_WALKER,55,10,0},
    {SP_WALKER,64,10,0}, {SP_WALKER,73,10,0}, {SP_WALKER,86,10,0},
    {SP_FLYER,21,8,2}, {SP_FLYER,40,8,2}, {SP_FLYER,75,7,3}
};

/* ------------------------------------------------------------------------
   Fase 2 - Praca Central (110 x 14)
   ------------------------------------------------------------------------ */
static const Span sp2[] = { {0,19,11}, {22,39,11}, {42,58,11}, {61,80,11}, {83,109,11} };
static const Block bl2[] =
{
    {15,9,3,1,TL_WOOD}, {34,9,3,1,TL_WOOD}, {38,7,3,1,TL_WOOD}, {44,9,3,1,TL_WOOD}, {49,7,4,1,TL_WOOD},
    {63,9,3,1,TL_WOOD}, {73,9,3,1,TL_WOOD}, {77,7,3,1,TL_WOOD}, {86,9,4,1,TL_WOOD}, {97,9,3,1,TL_WOOD},
    {10,9,1,2,TL_TRUNK}, {9,7,3,2,TL_CANOPY}, {31,9,1,2,TL_TRUNK}, {30,7,3,2,TL_CANOPY},
    {56,9,1,2,TL_TRUNK}, {55,7,3,2,TL_CANOPY}, {92,9,1,2,TL_TRUNK}, {91,7,3,2,TL_CANOPY},
    {6,10,1,1,TL_BENCH}, {13,10,1,1,TL_BENCH}, {70,10,1,1,TL_BENCH}, {102,10,1,1,TL_BENCH},
    {24,10,3,1,TL_FENCE}, {95,10,3,1,TL_FENCE},
    {27,10,2,1,TL_SPIKE}, {52,10,2,1,TL_SPIKE}, {67,10,2,1,TL_SPIKE}, {100,10,2,1,TL_SPIKE},
    {18,10,1,1,TL_FLOWER}, {40,10,1,1,TL_FLOWER}, {48,10,1,1,TL_FLOWER}, {75,10,1,1,TL_FLOWER},
    {105,10,1,1,TL_FLOWER}, {1,10,1,1,TL_SIGN}, {103,10,1,1,TL_SIGN}
};
static const Spawn ss2[] =
{
    {SP_START,2,10,0}, {SP_NPC,4,10,3}, {SP_NPC,105,10,4},
    {SP_COIN,8,9,3}, {SP_COIN,16,7,3}, {SP_COIN,35,7,3}, {SP_COIN,39,5,3}, {SP_COIN,45,7,3},
    {SP_COIN,50,5,4}, {SP_COIN,64,7,3}, {SP_COIN,74,7,3}, {SP_COIN,78,5,3}, {SP_COIN,87,7,4},
    {SP_COIN,98,7,3}, {SP_COIN,104,9,4},
    {SP_HEART,39,4,1}, {SP_HEART,78,4,1}, {SP_LIFE,50,4,1},
    {SP_CHECK,62,10,0}, {SP_GOAL,107,10,0},
    {SP_WALKER,13,10,0}, {SP_WALKER,25,10,0}, {SP_WALKER,36,10,0}, {SP_WALKER,46,10,0},
    {SP_WALKER,65,10,0}, {SP_WALKER,75,10,0}, {SP_WALKER,90,10,0}, {SP_WALKER,103,10,0},
    {SP_FLYER,16,8,2}, {SP_FLYER,30,8,2}, {SP_FLYER,57,8,2}, {SP_FLYER,93,8,2}, {SP_FLYER,96,7,3}
};

/* ------------------------------------------------------------------------
   Fase 3 - Grande Mangueira (20 x 56, fase vertical; galhos gerados em extra)
   ------------------------------------------------------------------------ */
static const Span sp3[] = { {0,19,54} };
static const Block bl3[] =
{
    {8,3,2,51,TL_TRUNK},            /* tronco central (cenario) */
    {3,1,14,2,TL_CANOPY},           /* copa */
    {15,53,1,1,TL_BUSH}, {17,53,1,1,TL_FLOWER}, {1,53,1,1,TL_SIGN}
};
static const Spawn ss3[] =
{
    {SP_START,3,53,0}, {SP_NPC,6,53,6}, {SP_NPC,5,5,8}, {SP_GOAL,12,5,0}
};

/* ------------------------------------------------------------------------
   Fase 4 - Parquinho da Turma (120 x 14)
   ------------------------------------------------------------------------ */
static const Span sp4[] = { {0,29,11}, {32,51,11}, {54,79,11}, {82,119,11} };
static const Block bl4[] =
{
    /* "rampas" de blocos de brinquedo */
    {10,10,1,1,TL_TOY}, {11,9,1,2,TL_TOY}, {12,8,1,3,TL_TOY}, {13,9,1,2,TL_TOY}, {14,10,1,1,TL_TOY},
    {40,10,1,1,TL_TOY}, {41,9,1,2,TL_TOY}, {42,10,1,1,TL_TOY},
    {64,10,1,1,TL_TOY}, {65,9,1,2,TL_TOY}, {66,10,1,1,TL_TOY},
    {110,10,1,1,TL_TOY}, {111,9,1,2,TL_TOY}, {112,8,1,3,TL_TOY}, {113,9,1,2,TL_TOY}, {114,10,1,1,TL_TOY},
    /* gangorras / brinquedos suspensos */
    {20,9,3,1,TL_WOOD}, {34,9,3,1,TL_WOOD}, {45,9,3,1,TL_WOOD}, {56,9,3,1,TL_WOOD},
    {68,9,3,1,TL_WOOD}, {85,9,3,1,TL_WOOD}, {96,9,3,1,TL_WOOD},
    {25,7,3,1,TL_WOOD}, {38,7,3,1,TL_WOOD}, {49,7,3,1,TL_WOOD}, {61,7,3,1,TL_WOOD},
    {73,7,3,1,TL_WOOD}, {90,7,4,1,TL_WOOD}, {101,7,3,1,TL_WOOD},
    {30,5,3,1,TL_WOOD}, {53,5,3,1,TL_WOOD},
    {36,10,2,1,TL_SPIKE}, {72,10,2,1,TL_SPIKE}, {94,10,2,1,TL_SPIKE}, {104,10,2,1,TL_SPIKE},
    {5,10,3,1,TL_FENCE}, {1,10,1,1,TL_SIGN}, {20,10,1,1,TL_BUSH}, {47,10,1,1,TL_FLOWER},
    {58,10,1,1,TL_FLOWER}, {80,10,1,1,TL_FLOWER}, {118,10,1,1,TL_SIGN}
};
static const Spawn ss4[] =
{
    {SP_START,2,10,0}, {SP_NPC,3,10,9}, {SP_NPC,115,10,10},
    {SP_COIN,10,7,5}, {SP_COIN,21,7,3}, {SP_COIN,26,5,3}, {SP_COIN,31,3,3}, {SP_COIN,35,7,3},
    {SP_COIN,39,5,3}, {SP_COIN,46,7,3}, {SP_COIN,50,5,3}, {SP_COIN,54,3,3}, {SP_COIN,57,7,3},
    {SP_COIN,62,5,3}, {SP_COIN,69,7,3}, {SP_COIN,74,5,3}, {SP_COIN,86,7,3}, {SP_COIN,91,5,4},
    {SP_COIN,97,7,3}, {SP_COIN,102,5,3}, {SP_COIN,111,6,3},
    {SP_HEART,12,6,1}, {SP_HEART,91,3,1}, {SP_LIFE,55,2,1},
    {SP_CHECK,55,10,0}, {SP_CHECK,90,10,0}, {SP_GOAL,117,10,0},
    {SP_WALKER,18,10,0}, {SP_WALKER,28,10,0}, {SP_WALKER,44,10,0}, {SP_WALKER,48,10,0},
    {SP_WALKER,60,10,0}, {SP_WALKER,70,10,0}, {SP_WALKER,88,10,0}, {SP_WALKER,100,10,0},
    {SP_WALKER,107,10,0},
    {SP_FLYER,25,8,2}, {SP_FLYER,47,8,2}, {SP_FLYER,76,8,2}, {SP_FLYER,105,7,3}
};

/* ------------------------------------------------------------------------
   Fase 5 - Aventura Final (150 x 14)
   ------------------------------------------------------------------------ */
static const Span sp5[] =
{
    {0,17,11}, {20,34,11}, {37,52,11}, {55,59,11}, {63,78,11}, {81,95,11}, {98,112,11}, {115,149,11}
};
static const Block bl5[] =
{
    {8,9,3,1,TL_WOOD}, {22,9,3,1,TL_WOOD}, {40,9,3,1,TL_WOOD}, {46,9,3,1,TL_WOOD}, {66,9,3,1,TL_WOOD},
    {84,9,3,1,TL_WOOD}, {100,9,3,1,TL_WOOD}, {117,9,3,1,TL_WOOD}, {127,9,3,1,TL_WOOD},
    {13,7,3,1,TL_WOOD}, {27,7,3,1,TL_WOOD}, {50,7,3,1,TL_WOOD}, {71,7,3,1,TL_WOOD}, {89,7,3,1,TL_WOOD},
    {105,7,3,1,TL_WOOD}, {122,7,3,1,TL_WOOD}, {132,7,3,1,TL_WOOD},
    {18,5,3,1,TL_WOOD}, {55,5,3,1,TL_WOOD}, {94,5,3,1,TL_WOOD}, {110,5,3,1,TL_WOOD},
    {26,10,2,1,TL_SPIKE}, {43,10,2,1,TL_SPIKE}, {48,10,2,1,TL_SPIKE}, {68,10,2,1,TL_SPIKE},
    {86,10,2,1,TL_SPIKE}, {103,10,2,1,TL_SPIKE}, {120,10,2,1,TL_SPIKE}, {130,10,2,1,TL_SPIKE},
    {76,10,1,1,TL_TOY}, {77,9,1,2,TL_TOY}, {78,10,1,1,TL_TOY},
    {58,10,1,1,TL_STONE}, {59,9,1,2,TL_STONE},
    {135,10,1,1,TL_STONE}, {136,9,1,2,TL_STONE}, {137,8,1,3,TL_STONE}, {138,9,1,2,TL_STONE}, {139,10,1,1,TL_STONE},
    {1,10,1,1,TL_SIGN}, {15,10,1,1,TL_BUSH}, {33,10,1,1,TL_FLOWER}, {91,10,1,1,TL_BUSH}, {109,10,1,1,TL_FLOWER}, {140,10,1,1,TL_SIGN}
};
static const Spawn ss5[] =
{
    {SP_START,2,10,0}, {SP_NPC,5,10,12},
    {SP_COIN,6,9,3}, {SP_COIN,9,7,3}, {SP_COIN,14,5,3}, {SP_COIN,19,3,3}, {SP_COIN,23,7,3},
    {SP_COIN,28,5,3}, {SP_COIN,38,9,3}, {SP_COIN,41,7,3}, {SP_COIN,47,7,3}, {SP_COIN,51,5,3},
    {SP_COIN,56,3,3}, {SP_COIN,57,9,2}, {SP_COIN,60,8,3}, {SP_COIN,67,7,3}, {SP_COIN,72,5,3},
    {SP_COIN,85,7,3}, {SP_COIN,90,5,3}, {SP_COIN,95,3,3}, {SP_COIN,101,7,3}, {SP_COIN,106,5,3},
    {SP_COIN,111,3,3}, {SP_COIN,118,7,3}, {SP_COIN,123,5,3}, {SP_COIN,128,7,3}, {SP_COIN,133,5,3},
    {SP_HEART,15,4,1}, {SP_HEART,90,4,1}, {SP_HEART,123,4,1}, {SP_LIFE,19,2,1}, {SP_LIFE,111,2,1},
    {SP_CHECK,38,10,0}, {SP_CHECK,82,10,0}, {SP_CHECK,116,10,0},
    {SP_NPC,141,10,13}, {SP_NPC,143,10,14}, {SP_NPC,145,10,15}, {SP_GOAL,147,10,0},
    {SP_WALKER,10,10,0}, {SP_WALKER,23,10,0}, {SP_WALKER,31,10,0}, {SP_WALKER,41,10,0},
    {SP_WALKER,50,10,0}, {SP_WALKER,57,10,0}, {SP_WALKER,67,10,0}, {SP_WALKER,74,10,0},
    {SP_WALKER,85,10,0}, {SP_WALKER,92,10,0}, {SP_WALKER,101,10,0}, {SP_WALKER,108,10,0},
    {SP_WALKER,118,10,0}, {SP_WALKER,126,10,0},
    {SP_FLYER,31,8,2}, {SP_FLYER,45,8,2}, {SP_FLYER,68,8,2}, {SP_FLYER,74,8,2},
    {SP_FLYER,90,8,2}, {SP_FLYER,108,8,2}
};

/* ------------------------------------------------------------------------ */
static void spawn(u8 type, u8 x, u8 y, u8 n)
{
    switch (type)
    {
        case SP_START:  player_setStart(x, y); break;
        case SP_WALKER: enemies_add(0, x, y, n); break;
        case SP_FLYER:  enemies_add(1, x, y, n); break;
        default:        items_add(type, x, y, n); break;
    }
}

static void fillRect(u8 x, u8 y, u8 w, u8 h, u8 tile)
{
    u8 i, j;
    for (j = 0; j < h; j++)
    {
        if (y + j >= lvH) break;
        for (i = 0; i < w; i++)
        {
            if (x + i >= lvW) break;
            lvMap[(y + j) * lvW + x + i] = tile;
        }
    }
}

/* galhos em ziguezague da Grande Mangueira (sobem 2 celulas por galho) */
static void extraMangueira(void)
{
    u8 i;
    for (i = 0; i < 23; i++)
    {
        u8 y = 52 - 2 * i;
        bool left = ((i & 1) == 0);
        fillRect(left ? 1 : 10, y, left ? 8 : 9, 1, TL_LEAFPLAT);   /* vao de 1 celula (o tronco) entre os galhos */
        spawn(SP_COIN, left ? 3 : 12, y - 1, 3);
        if ((i % 4) == 1) spawn(SP_WALKER, 14, y - 1, 0);
        if (i == 11) spawn(SP_CHECK, 16, y - 1, 0);
        if (i == 5 || i == 15) spawn(SP_HEART, 14, y - 2, 1);
        if (i == 19) spawn(SP_LIFE, 14, y - 2, 1);
    }
    fillRect(2, 6, 16, 1, TL_LEAFPLAT);       /* galho final, onde esta a bandeira */
    spawn(SP_COIN, 4, 5, 3);
    spawn(SP_COIN, 14, 5, 2);
}

#define COUNT(a) ((u8)(sizeof(a) / sizeof((a)[0])))

const LevelDef gLevels[NUM_LEVELS] =
{
    { "FASE 1 - BAIRRO DAS MANGUEIRAS", 100, 14, 0, sp1, COUNT(sp1), bl1, COUNT(bl1), ss1, COUNT(ss1), NULL },
    { "FASE 2 - PRACA CENTRAL",         110, 14, 1, sp2, COUNT(sp2), bl2, COUNT(bl2), ss2, COUNT(ss2), NULL },
    { "FASE 3 - GRANDE MANGUEIRA",       20, 56, 2, sp3, COUNT(sp3), bl3, COUNT(bl3), ss3, COUNT(ss3), extraMangueira },
    { "FASE 4 - PARQUINHO DA TURMA",    120, 14, 3, sp4, COUNT(sp4), bl4, COUNT(bl4), ss4, COUNT(ss4), NULL },
    { "FASE 5 - AVENTURA FINAL",        150, 14, 4, sp5, COUNT(sp5), bl5, COUNT(bl5), ss5, COUNT(ss5), NULL }
};

u8 levels_tile(s16 cx, s16 cy)
{
    if (cx < 0 || cy < 0 || cx >= lvW || cy >= lvH) return TL_EMPTY;
    return lvMap[cy * lvW + cx];
}

void levels_load(u8 idx)
{
    const LevelDef *d = &gLevels[idx];
    u8 i, x, y;

    lvW = d->w;
    lvH = d->h;
    {   /* limpa o mapa */
        u16 n = (u16)lvW * lvH, k;
        for (k = 0; k < n; k++) lvMap[k] = TL_EMPTY;
    }

    for (i = 0; i < d->nSpans; i++)
    {
        const Span *s = &d->spans[i];
        for (x = s->x0; x <= s->x1 && x < lvW; x++)
        {
            lvMap[s->top * lvW + x] = TL_GRASS;
            for (y = s->top + 1; y < lvH; y++) lvMap[y * lvW + x] = TL_DIRT;
        }
    }
    for (i = 0; i < d->nBlocks; i++)
    {
        const Block *b = &d->blocks[i];
        fillRect(b->x, b->y, b->w, b->h, b->tile);
    }
    for (i = 0; i < d->nSpawns; i++)
    {
        const Spawn *s = &d->spawns[i];
        spawn(s->type, s->x, s->y, s->n);
    }
    if (d->extra) d->extra();
}

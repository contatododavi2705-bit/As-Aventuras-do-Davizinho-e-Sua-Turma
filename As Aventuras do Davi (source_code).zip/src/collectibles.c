#include "collectibles.h"
#include "levels.h"
#include "player.h"

#define MAX_ITEMS 110

typedef struct
{
    u8      type;
    bool    active;     /* moeda/coracao/vida: ainda nao coletado; checkpoint: ja ativado */
    u8      arg;        /* NPC: indice da fala */
    s16     x, y;       /* moedas/itens: centro; checkpoint/bandeira/NPC: centro x, pe y */
    Sprite *spr;
} Item;

static Item items[MAX_ITEMS];
static u8 numItems;
const char *gDialogue;

void items_reset(void)
{
    numItems = 0;
    gDialogue = NULL;
}

static void addOne(u8 type, s16 x, s16 y, u8 arg)
{
    Item *it;
    if (numItems >= MAX_ITEMS) return;
    it = &items[numItems++];
    it->type = type;
    it->active = (type != SP_CHECK);
    it->arg = arg;
    it->x = x;
    it->y = y;
    it->spr = NULL;
}

void items_add(u8 type, u8 cx, u8 cy, u8 n)
{
    u8 i;
    switch (type)
    {
        case SP_COIN:
            for (i = 0; i < (n ? n : 1); i++) addOne(SP_COIN, (cx + i) * CELL + 8, cy * CELL + 8, 0);
            break;
        case SP_HEART:
        case SP_LIFE:
            addOne(type, cx * CELL + 8, cy * CELL + 8, 0);
            break;
        default:    /* checkpoint, bandeira, NPC */
            addOne(type, cx * CELL + 8, (cy + 1) * CELL, n);
            break;
    }
}

static void createSprite(Item *it)
{
    switch (it->type)
    {
        case SP_COIN:  it->spr = SPR_addSprite(&spr_items, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE)); if (it->spr) SPR_setAnim(it->spr, 0); break;
        case SP_HEART: it->spr = SPR_addSprite(&spr_items, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE)); if (it->spr) SPR_setAnim(it->spr, 1); break;
        case SP_LIFE:  it->spr = SPR_addSprite(&spr_items, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE)); if (it->spr) SPR_setAnim(it->spr, 2); break;
        case SP_CHECK: it->spr = SPR_addSprite(&spr_items, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE)); if (it->spr) SPR_setAnim(it->spr, it->active ? 4 : 3); break;
        case SP_GOAL:  it->spr = SPR_addSprite(&spr_goal, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE)); break;
        case SP_NPC:   it->spr = SPR_addSprite(&spr_turma, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE)); if (it->spr) SPR_setAnim(it->spr, gDialogs[it->arg & 15].who); break;
    }
}

static void place(Item *it)
{
    s16 sx = it->x - gCamX, sy = it->y - gCamY;
    switch (it->type)
    {
        case SP_COIN: case SP_HEART: case SP_LIFE: SPR_setPosition(it->spr, sx - 8, sy - 8); break;
        case SP_CHECK:                              SPR_setPosition(it->spr, sx - 8, sy - 16); break;
        default:                                    SPR_setPosition(it->spr, sx - 8, sy - 32); break;
    }
}

static void release(Item *it)
{
    if (it->spr) { SPR_releaseSprite(it->spr); it->spr = NULL; }
}

void items_update(void)
{
    Player *p = &gPlayer;
    s16 pcx = (s16)(p->b.x >> 8);
    s16 pfy = (s16)(p->b.y >> 8);
    s16 pcy = pfy - 14;
    bool alive = (p->state == PS_NORMAL || p->state == PS_HURT);
    const char *talk = NULL;
    u8 i;

    for (i = 0; i < numItems; i++)
    {
        Item *it = &items[i];
        s16 dx = it->x - (gCamX + SCREEN_W / 2);
        s16 dy = it->y - (gCamY + SCREEN_H / 2);
        bool visible = (dx > -200 && dx < 200 && dy > -160 && dy < 160);
        s16 ax, ay;

        if (!it->active && it->type != SP_CHECK) continue;

        if (!visible) { release(it); continue; }
        if (!it->spr) { createSprite(it); if (!it->spr) continue; }
        place(it);

        if (!alive) continue;
        ax = pcx - it->x; if (ax < 0) ax = -ax;

        switch (it->type)
        {
            case SP_COIN:
            case SP_HEART:
            case SP_LIFE:
                ay = pcy - it->y; if (ay < 0) ay = -ay;
                if (ax < 14 && ay < 20)
                {
                    it->active = FALSE;
                    release(it);
                    if (it->type == SP_COIN)
                    {
                        gGame.coins++;
                        game_addScore(10);
                        game_playSfx(SFX_COIN);
                        if (gGame.coins >= 50)
                        {
                            gGame.coins = 0;
                            if (gGame.lives < 9) gGame.lives++;
                            game_playSfx(SFX_ONEUP);
                        }
                    }
                    else if (it->type == SP_HEART)
                    {
                        if (p->health < 3) p->health++;
                        else game_addScore(50);
                        game_playSfx(SFX_HEART);
                    }
                    else
                    {
                        if (gGame.lives < 9) gGame.lives++;
                        game_addScore(200);
                        game_playSfx(SFX_ONEUP);
                    }
                }
                break;

            case SP_CHECK:
                ay = pcy - (it->y - 16); if (ay < 0) ay = -ay;
                if (!it->active && ax < 14 && ay < 24)
                {
                    it->active = TRUE;
                    p->cpX = it->x;
                    p->cpY = it->y;
                    SPR_setAnim(it->spr, 4);
                    game_playSfx(SFX_CHECK);
                    game_addScore(25);
                }
                break;

            case SP_GOAL:
                ay = pcy - (it->y - 16); if (ay < 0) ay = -ay;
                if (p->state == PS_NORMAL && ax < 12 && ay < 28)
                {
                    game_addScore(500);
                    player_win();
                }
                break;

            case SP_NPC:
                ay = pcy - (it->y - 16); if (ay < 0) ay = -ay;
                if (ax < 56 && ay < 40) talk = gDialogs[it->arg & 15].text;
                break;
        }
    }
    gDialogue = talk;
}

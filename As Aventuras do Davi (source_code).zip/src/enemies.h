#ifndef _ENEMIES_H_
#define _ENEMIES_H_

#include "game.h"

void enemies_reset(void);
void enemies_add(u8 type, u8 cx, u8 cy, u8 n);    /* type 0 = caramujo, 1 = abelha */
void enemies_update(void);
bool enemies_hitPoint(s16 x, s16 y);             /* usado pela estrela lancada */

#endif

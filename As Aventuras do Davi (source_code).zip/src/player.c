#include "player.h"
#include "levels.h"
#include "enemies.h"

/* animacoes (linhas de res/sprites/davi.png) */
#define ANIM_IDLE   0
#define ANIM_WALK   1
#define ANIM_RUN    2
#define ANIM_JUMP   3
#define ANIM_FALL   4
#define ANIM_HURT   5
#define ANIM_WIN    6

/* fisica em 1/256 pixel por quadro */
#define GRAVITY     72
#define MAX_FALL    1600
#define WALK_MAX    400
#define RUN_MAX     640
#define RUN_ANIM    500
#define ACCEL       20
#define AIR_ACCEL   14
#define FRICTION    28
#define AIR_FRICT   6
#define JUMP_V      (-1300)
#define JUMP_CUT    (-420)

Player gPlayer;

typedef struct { bool active; s16 x, y, vx; u8 life; Sprite *spr; } Star;
static Star star;

static void setAnim(u8 a)
{
    if (gPlayer.anim != a)
    {
        gPlayer.anim = a;
        if (gPlayer.spr) SPR_setAnim(gPlayer.spr, a);
    }
}

void player_create(void)
{
    gPlayer.spr = SPR_addSprite(&spr_davi, 0, 0, TILE_ATTR(PAL_DAVI, FALSE, FALSE, FALSE));
    gPlayer.anim = 0xFF;
    star.active = FALSE;
    star.spr = NULL;
}

void player_setStart(u8 cx, u8 cy)
{
    gPlayer.cpX = cx * CELL + CELL / 2;
    gPlayer.cpY = (cy + 1) * CELL;
}

void player_respawn(void)
{
    Body *b = &gPlayer.b;
    b->x = ((s32)gPlayer.cpX) << 8;
    b->y = ((s32)gPlayer.cpY) << 8;
    b->vx = 0; b->vy = 0;
    b->hw = 6; b->h = 28;
    b->ground = FALSE; b->wall = FALSE;
    gPlayer.state = PS_NORMAL;
    gPlayer.health = 3;
    gPlayer.inv = 90;
    gPlayer.timer = 0;
    gPlayer.hurtTimer = 0;
    gPlayer.coyote = 0;
    gPlayer.jumpBuf = 0;
    gPlayer.jumping = FALSE;
    gPlayer.faceLeft = FALSE;
    gPlayer.anim = 0xFF;
    if (star.active)
    {
        star.active = FALSE;
        if (star.spr) { SPR_releaseSprite(star.spr); star.spr = NULL; }
    }
}

void player_hurt(void)
{
    Player *p = &gPlayer;
    if (p->inv > 0 || p->state == PS_DEAD || p->state == PS_WIN) return;
    if (p->health > 0) p->health--;
    game_playSfx(SFX_HURT);
    if (p->health == 0) { player_kill(); return; }
    p->state = PS_HURT;
    p->hurtTimer = 24;
    p->inv = 120;
    p->jumping = FALSE;
    p->b.vy = -700;
    p->b.vx = p->faceLeft ? 500 : -500;
    p->b.ground = FALSE;
}

void player_kill(void)
{
    Player *p = &gPlayer;
    if (p->state == PS_DEAD || p->state == PS_WIN) return;
    p->state = PS_DEAD;
    p->timer = 0;
    p->health = 0;
    p->b.vy = -1300;
    p->b.vx = 0;
    p->inv = 0;
    XGM_stopPlay();
    game_playSfx(SFX_HURT);
}

void player_win(void)
{
    Player *p = &gPlayer;
    if (p->state == PS_DEAD || p->state == PS_WIN) return;
    p->state = PS_WIN;
    p->timer = 0;
    p->inv = 0;
    game_playSfx(SFX_GOAL);
}

void player_bounce(void)
{
    gPlayer.b.vy = (gPad & JUMP_MASK) ? -1100 : -750;
    gPlayer.b.ground = FALSE;
    gPlayer.jumping = TRUE;
}

static void shoot(void)
{
    if (star.active) return;
    star.spr = SPR_addSprite(&spr_items, 0, 0, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE));
    if (!star.spr) return;
    SPR_setAnim(star.spr, 5);
    star.active = TRUE;
    star.life = 50;
    star.vx = gPlayer.faceLeft ? -4 : 4;
    star.x = (s16)(gPlayer.b.x >> 8) + (gPlayer.faceLeft ? -10 : 10);
    star.y = (s16)(gPlayer.b.y >> 8) - 16;
    game_playSfx(SFX_STAR);
}

void projectile_update(void)
{
    if (!star.active) return;
    star.x += star.vx;
    star.life--;
    if (star.life == 0 || col_class(star.x, star.y) == T_SOLID || enemies_hitPoint(star.x, star.y))
    {
        star.active = FALSE;
        if (star.spr) { SPR_releaseSprite(star.spr); star.spr = NULL; }
        return;
    }
    SPR_setPosition(star.spr, star.x - 8 - gCamX, star.y - 8 - gCamY);
}

void player_update(void)
{
    Player *p = &gPlayer;
    Body *b = &p->b;
    s16 dir = 0;

    p->timer++;

    if (p->state == PS_DEAD)
    {
        b->vy += GRAVITY;
        if (b->vy > MAX_FALL) b->vy = MAX_FALL;
        b->y += b->vy;
        setAnim(ANIM_HURT);
        return;
    }

    if (p->state == PS_WIN)
    {
        if (b->vx > 0) { b->vx -= FRICTION; if (b->vx < 0) b->vx = 0; }
        else if (b->vx < 0) { b->vx += FRICTION; if (b->vx > 0) b->vx = 0; }
        b->vy += GRAVITY;
        if (b->vy > MAX_FALL) b->vy = MAX_FALL;
        col_moveX(b);
        col_moveY(b);
        setAnim(ANIM_WIN);
        return;
    }

    if (p->state == PS_HURT)
    {
        if (p->hurtTimer > 0) p->hurtTimer--;
        if (p->hurtTimer == 0) p->state = PS_NORMAL;
    }
    else
    {
        if (gPad & BUTTON_LEFT) dir = -1;
        else if (gPad & BUTTON_RIGHT) dir = 1;

        if (dir != 0)
        {
            s16 acc = b->ground ? ACCEL : AIR_ACCEL;
            if ((dir > 0 && b->vx < 0) || (dir < 0 && b->vx > 0)) acc += ACCEL;
            b->vx += dir * acc;
            if (b->vx > RUN_MAX) b->vx = RUN_MAX;
            if (b->vx < -RUN_MAX) b->vx = -RUN_MAX;
            p->faceLeft = (dir < 0);
        }
        else
        {
            s16 f = b->ground ? FRICTION : AIR_FRICT;
            if (b->vx > 0) { b->vx -= f; if (b->vx < 0) b->vx = 0; }
            else if (b->vx < 0) { b->vx += f; if (b->vx > 0) b->vx = 0; }
        }

        /* pulo com "coyote time" e buffer de entrada */
        if (PRESSED(JUMP_MASK)) p->jumpBuf = 6;
        else if (p->jumpBuf > 0) p->jumpBuf--;
        if (p->jumpBuf > 0 && p->coyote > 0 && !p->jumping)
        {
            b->vy = JUMP_V;
            p->jumping = TRUE;
            p->coyote = 0;
            p->jumpBuf = 0;
            b->ground = FALSE;
            game_playSfx(SFX_JUMP);
        }
        if (p->jumping && b->vy < JUMP_CUT && !(gPad & JUMP_MASK)) b->vy = JUMP_CUT;

        if (PRESSED(BUTTON_A)) shoot();
    }

    b->vy += GRAVITY;
    if (b->vy > MAX_FALL) b->vy = MAX_FALL;
    col_moveX(b);
    col_moveY(b);

    if (b->ground) { p->coyote = 6; p->jumping = FALSE; }
    else if (p->coyote > 0) p->coyote--;

    /* nunca sai do cenario pelos lados */
    if ((b->x >> 8) < b->hw) b->x = ((s32)b->hw) << 8;
    if ((b->x >> 8) > (s32)(lvW * CELL - b->hw)) b->x = ((s32)(lvW * CELL - b->hw)) << 8;

    /* queda no abismo */
    if ((b->y >> 8) > (s32)(lvH * CELL + 48)) { player_kill(); return; }

    if (p->inv > 0) p->inv--;
    if (p->inv == 0 && col_hazard(b)) player_hurt();

    /* animacao */
    if (p->state == PS_HURT) setAnim(ANIM_HURT);
    else if (!b->ground) setAnim(b->vy < 0 ? ANIM_JUMP : ANIM_FALL);
    else
    {
        s16 av = b->vx < 0 ? -b->vx : b->vx;
        if (av >= RUN_ANIM) setAnim(ANIM_RUN);
        else if (av > 40) setAnim(ANIM_WALK);
        else setAnim(ANIM_IDLE);
    }
}

void player_draw(void)
{
    Player *p = &gPlayer;
    if (!p->spr) return;
    SPR_setPosition(p->spr, (s16)(p->b.x >> 8) - 12 - gCamX, (s16)(p->b.y >> 8) - 31 - gCamY);
    SPR_setHFlip(p->spr, p->faceLeft);
    if (p->inv > 0 && (p->inv & 4) && p->state != PS_DEAD) SPR_setVisibility(p->spr, HIDDEN);
    else SPR_setVisibility(p->spr, AUTO_FAST);
}

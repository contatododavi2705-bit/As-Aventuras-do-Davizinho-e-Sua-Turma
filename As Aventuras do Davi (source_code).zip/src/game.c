#include "game.h"
#include "levels.h"
#include "player.h"
#include "enemies.h"
#include "collectibles.h"
#include "collision.h"

GameData gGame;
u16 gPad, gPadPrev;
s16 gCamX, gCamY;
u8 gScreen;

static const u8 *const songs[7] =
{
    mus_fase1, mus_fase2, mus_fase3, mus_fase4, mus_fase5, mus_vitoria, mus_gameover
};

static const u8 *const sfxData[SFX_COUNT] =
{
    sfx_jump, sfx_coin, sfx_hurt, sfx_stomp, sfx_star, sfx_oneup, sfx_check, sfx_goal, sfx_heart
};
static const u32 sfxLen[SFX_COUNT] =
{
    sizeof(sfx_jump), sizeof(sfx_coin), sizeof(sfx_hurt), sizeof(sfx_stomp), sizeof(sfx_star),
    sizeof(sfx_oneup), sizeof(sfx_check), sizeof(sfx_goal), sizeof(sfx_heart)
};

/* ------------------------------------------------------------------------ */
void game_init(void)
{
    u8 i;

    SPR_initEx(SPR_VRAM_TILES);
    Z80_loadDriver(Z80_DRIVER_XGM, TRUE);
    for (i = 0; i < SFX_COUNT; i++) XGM_setPCM(SFX_FIRST_ID + i, sfxData[i], sfxLen[i]);

    VDP_loadTileSet(&ts_terrain, TILE_TERRAIN, DMA);
    VDP_loadTileSet(&ts_bg, TILE_BG, DMA);

    gGame.unlocked = 0;
    game_newGame();
}

void game_newGame(void)
{
    gGame.lives = 3;
    gGame.coins = 0;
    gGame.score = 0;
}

void game_retry(void)
{
    gGame.lives = 3;
    gGame.coins = 0;
}

const char *game_objective(u8 idx)
{
    return (idx == NUM_LEVELS - 1) ? "DESAFIO FINAL: ALCANCE A BANDEIRA DA TURMA!"
                                   : "OBJETIVO: ALCANCE A BANDEIRA NO FIM DA FASE!";
}

void game_readPad(void)
{
    gPadPrev = gPad;
    gPad = JOY_readJoypad(JOY_1);
}

void game_addScore(u32 pts)
{
    gGame.score += pts;
    if (gGame.score > 999999) gGame.score = 999999;
}

void game_playSfx(u8 id)
{
    if (id < SFX_COUNT) XGM_startPlayPCM(SFX_FIRST_ID + id, 1, SOUND_PCM_CH2);
}

void game_playMusic(u8 id)
{
    if (id > MUS_GAMEOVER) return;
    XGM_startPlay(songs[id]);
}

/* ------------------------------------------------------------------------
   Rolagem: o mapa 2D e transmitido para a plano A (64x32 tiles) aos poucos.
   Janela = 21 colunas x 15 linhas de celulas; ao cruzar uma celula, apenas a
   nova coluna/linha e desenhada (o plano "da a volta" via modulo).
   ------------------------------------------------------------------------ */
static s16 drawnCX, drawnCY;

static void drawCell(s16 cx, s16 cy)
{
    u16 t = levels_tile(cx, cy) & 15;
    u16 base = TILE_TERRAIN + t * 4;
    u16 tx = (cx * 2) & 63;
    u16 ty = (cy * 2) & 31;
    VDP_setTileMapXY(BG_A, TILE_ATTR_FULL(PAL_TERRAIN, FALSE, FALSE, FALSE, base),     tx,     ty);
    VDP_setTileMapXY(BG_A, TILE_ATTR_FULL(PAL_TERRAIN, FALSE, FALSE, FALSE, base + 1), tx + 1, ty);
    VDP_setTileMapXY(BG_A, TILE_ATTR_FULL(PAL_TERRAIN, FALSE, FALSE, FALSE, base + 2), tx,     ty + 1);
    VDP_setTileMapXY(BG_A, TILE_ATTR_FULL(PAL_TERRAIN, FALSE, FALSE, FALSE, base + 3), tx + 1, ty + 1);
}

static void streamColumn(s16 cx, s16 cy0)
{
    s16 r;
    for (r = 0; r < 15; r++) drawCell(cx, cy0 + r);
}

static void streamRow(s16 cy, s16 cx0)
{
    s16 c;
    for (c = 0; c < 21; c++) drawCell(cx0 + c, cy);
}

static void streamReset(void)
{
    s16 r, c;
    drawnCX = gCamX >> 4;
    drawnCY = gCamY >> 4;
    for (r = 0; r < 15; r++)
        for (c = 0; c < 21; c++) drawCell(drawnCX + c, drawnCY + r);
}

static void streamUpdate(void)
{
    s16 tx = gCamX >> 4;
    s16 ty = gCamY >> 4;
    while (drawnCX < tx) { drawnCX++; streamColumn(drawnCX + 20, drawnCY); }
    while (drawnCX > tx) { drawnCX--; streamColumn(drawnCX, drawnCY); }
    while (drawnCY < ty) { drawnCY++; streamRow(drawnCY + 14, drawnCX); }
    while (drawnCY > ty) { drawnCY--; streamRow(drawnCY, drawnCX); }
}

static void applyScroll(void)
{
    VDP_setHorizontalScroll(BG_A, -gCamX);
    VDP_setVerticalScroll(BG_A, gCamY);
    VDP_setHorizontalScroll(BG_B, -(gCamX >> 2));
}

static void cameraUpdate(bool snap)
{
    s16 px = (s16)(gPlayer.b.x >> 8);
    s16 py = (s16)(gPlayer.b.y >> 8);
    s16 maxX = lvW * CELL - SCREEN_W;
    s16 maxY = lvH * CELL - SCREEN_H;
    s16 tx = px - SCREEN_W / 2;
    s16 ty = py - 150;

    if (tx < 0) tx = 0;
    if (tx > maxX) tx = maxX;
    gCamX = tx;

    if (maxY <= 0) { gCamY = 0; return; }
    if (ty < 0) ty = 0;
    if (ty > maxY) ty = maxY;
    if (snap) gCamY = ty;
    else
    {
        s16 step = (ty - gCamY) / 4;
        if (step > 8) step = 8;
        if (step < -8) step = -8;
        gCamY += step;
        if (gCamY < 0) gCamY = 0;
        if (gCamY > maxY) gCamY = maxY;
    }
}

/* ------------------------------------------------------------------------
   Fundo (plano B): colinas em silhueta + nuvens, rolagem parallax 1/4
   ------------------------------------------------------------------------ */
static void drawBackground(bool pits)
{
    u16 x, i;
    for (x = 0; x < 64; x++)
    {
        s16 h = 56 + (sinFix16((x * 16) & 1023) >> 6) + (sinFix16((x * 32 + 200) & 1023) >> 7);
        s16 topPix = SCREEN_H - h;
        s16 topRow = topPix >> 3;
        u16 k = 8 - (topPix & 7);
        s16 r;
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + k), x, topRow);
        if (topRow + 1 < 28) VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 8), x, topRow + 1);
        for (r = topRow + 2; r < 28; r++)
            VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 13), x, r);
    }
    /* faixa escura atras do HUD (a janela e transparente) */
    for (x = 0; x < 64; x++)
    {
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 14), x, 0);
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 14), x, 1);
    }
    /* fases horizontais: abaixo do chao o fundo e um vazio escuro (buracos) */
    if (pits)
    {
        u16 r;
        for (r = 22; r < 28; r++)
            for (x = 0; x < 64; x++)
                VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 15), x, r);
    }
    for (i = 0; i < 7; i++)
    {
        u16 cx = (i * 13 + 5) % 62;
        u16 cy = 3 + (i * 5) % 6;
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 9),  cx,     cy);
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 10), cx + 1, cy);
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 11), cx,     cy + 1);
        VDP_setTileMapXY(BG_B, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_BG + 12), cx + 1, cy + 1);
    }
}

/* ------------------------------------------------------------------------
   HUD na janela (plano WINDOW): linha 0 = status, linha 1 = falas
   ------------------------------------------------------------------------ */
static u8 hudLives, hudHealth, hudCoins;
static u32 hudScore;
static const char *hudLine;
static bool hudForce;

static void drawNum(u32 v, u16 x, u16 y, s16 digits)
{
    char buf[12];
    uintToStr(v, buf, digits);
    VDP_drawText(buf, x, y);
}

static void hudUpdate(const char *line)
{
    if (hudForce)
    {
        VDP_clearText(0, 0, 40);
        VDP_drawText("VIDAS", 1, 0);
        VDP_drawText("HP", 10, 0);
        VDP_drawText("MOEDAS", 17, 0);
        VDP_drawText("PTS", 29, 0);
        hudLives = 255; hudHealth = 255; hudCoins = 255; hudScore = 0xFFFFFFFF;
        hudLine = (const char *)1;
        hudForce = FALSE;
    }
    if (hudLives != gGame.lives) { hudLives = gGame.lives; drawNum(hudLives, 7, 0, 1); }
    if (hudHealth != gPlayer.health)
    {
        hudHealth = gPlayer.health;
        VDP_drawText("   ", 13, 0);
        VDP_drawText(hudHealth == 3 ? "***" : hudHealth == 2 ? "** " : hudHealth == 1 ? "*  " : "   ", 13, 0);
    }
    if (hudCoins != gGame.coins) { hudCoins = gGame.coins; drawNum(hudCoins, 24, 0, 2); }
    if (hudScore != gGame.score) { hudScore = gGame.score; drawNum(hudScore, 33, 0, 6); }
    if (hudLine != line)
    {
        hudLine = line;
        VDP_clearText(0, 1, 40);
        if (line) VDP_drawText(line, 1, 1);
    }
}

/* ------------------------------------------------------------------------ */
static void levelSetup(u8 idx)
{
    const LevelDef *d = &gLevels[idx];

    VDP_setEnable(FALSE);
    SPR_reset();
    VDP_clearPlane(BG_A, TRUE);
    VDP_clearPlane(BG_B, TRUE);
    VDP_clearPlane(WINDOW, TRUE);

    PAL_setPalette(PAL_TERRAIN, levels_palTerrain(d->theme), CPU);
    PAL_setPalette(PAL_BG, levels_palBg(d->theme), CPU);
    PAL_setPalette(PAL_DAVI, spr_davi.palette->data, CPU);
    PAL_setPalette(PAL_ENT, spr_items.palette->data, CPU);

    VDP_setTextPlane(WINDOW);
    VDP_setWindowHPos(FALSE, 0);
    VDP_setWindowVPos(FALSE, 2);

    enemies_reset();
    items_reset();
    player_create();
    levels_load(idx);
    player_respawn();
    gPlayer.inv = 0;

    drawBackground(d->h <= 14);
    cameraUpdate(TRUE);
    streamReset();
    applyScroll();
    hudForce = TRUE;
    VDP_setEnable(TRUE);

    game_playMusic(idx);
}

static LevelResult pauseLoop(void)
{
    gScreen = SCR_PAUSE;
    XGM_pausePlay();
    VDP_clearText(0, 1, 40);
    VDP_drawText("PAUSA - START:CONTINUA  A:REINICIA", 2, 1);
    while (TRUE)
    {
        SYS_doVBlankProcess();
        game_readPad();
        if (PRESSED(BUTTON_START)) break;
        if (PRESSED(BUTTON_A))
        {
            XGM_resumePlay();
            return RES_RESTART;
        }
    }
    XGM_resumePlay();
    gScreen = SCR_PLAY;
    hudLine = (const char *)1;      /* forca redesenho da linha de falas */
    return RES_COMPLETE;
}

LevelResult game_playLevel(u8 idx)
{
    u16 intro = 260;

    gPad = gPadPrev = 0;
    gScreen = SCR_PLAY;
    levelSetup(idx);

    while (TRUE)
    {
        game_readPad();

        if (PRESSED(BUTTON_START) && gPlayer.state != PS_DEAD && gPlayer.state != PS_WIN)
        {
            if (pauseLoop() == RES_RESTART)
            {
                VDP_setWindowVPos(FALSE, 0);
                return RES_RESTART;
            }
        }

        player_update();
        if (gPlayer.state != PS_DEAD) cameraUpdate(FALSE);
        streamUpdate();
        applyScroll();
        projectile_update();
        enemies_update();
        items_update();
        player_draw();

        if (intro > 0) intro--;
        hudUpdate(intro > 130 ? gLevels[idx].name : (intro > 0 ? game_objective(idx) : gDialogue));

        SPR_update();
        SYS_doVBlankProcess();

        if (gPlayer.state == PS_DEAD && gPlayer.timer > 100)
        {
            if (gGame.lives > 0) gGame.lives--;
            if (gGame.lives == 0)
            {
                VDP_setWindowVPos(FALSE, 0);
                return RES_GAMEOVER;
            }
            player_respawn();
            cameraUpdate(TRUE);
            streamReset();
            applyScroll();
            game_playMusic(idx);
        }
        else if (gPlayer.state == PS_WIN && gPlayer.timer > 150)
        {
            VDP_setWindowVPos(FALSE, 0);
            return RES_COMPLETE;
        }
    }
}

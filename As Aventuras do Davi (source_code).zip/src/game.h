#ifndef _GAME_H_
#define _GAME_H_

#include <genesis.h>
#include "resources.h"

#define SCREEN_W        320
#define SCREEN_H        224
#define CELL            16          /* cada celula do mapa = 16x16 px = 2x2 tiles */
#define NUM_LEVELS      5

/* paletas: PAL0 terreno/texto, PAL1 fundo, PAL2 Davi, PAL3 inimigos/itens/turma */
#define PAL_TERRAIN     PAL0
#define PAL_BG          PAL1
#define PAL_DAVI        PAL2
#define PAL_ENT         PAL3

/* layout da VRAM (em tiles). O motor de sprites reserva SPR_VRAM_TILES a partir
   de TILE_USER_INDEX; os tilesets do jogo ficam logo depois. */
#define SPR_VRAM_TILES  320
#define TILE_TERRAIN    (TILE_USER_INDEX + SPR_VRAM_TILES)
#define TILE_BG         (TILE_TERRAIN + 64)
#define TILE_TITLE      (TILE_BG + 16)

/* cor do Mega Drive a partir de componentes 0..7 */
#define C3(r, g, b)     ((u16)(((b) << 9) | ((g) << 5) | ((r) << 1)))

enum { SFX_JUMP, SFX_COIN, SFX_HURT, SFX_STOMP, SFX_STAR, SFX_ONEUP, SFX_CHECK, SFX_GOAL, SFX_HEART, SFX_COUNT };
#define SFX_FIRST_ID    64

enum { MUS_FASE1, MUS_FASE2, MUS_FASE3, MUS_FASE4, MUS_FASE5, MUS_VITORIA, MUS_GAMEOVER };

typedef enum { RES_COMPLETE, RES_GAMEOVER, RES_RESTART } LevelResult;

/* tela atual (usada pela logica de fluxo e pelos testes automatizados) */
typedef enum { SCR_TITLE, SCR_SELECT, SCR_INTRO, SCR_PLAY, SCR_PAUSE, SCR_COMPLETE,
               SCR_GAMEOVER, SCR_ENDING, SCR_CREDITS, SCR_ENDCHOICE } Screen;
extern u8 gScreen;

typedef struct
{
    u8  lives;
    u8  coins;
    u32 score;
    u8  unlocked;       /* maior fase liberada (0..NUM_LEVELS-1) */
} GameData;

extern GameData gGame;
extern u16 gPad, gPadPrev;
extern s16 gCamX, gCamY;

#define PRESSED(b)      (((gPad) & (b)) && !((gPadPrev) & (b)))
#define JUMP_MASK       (BUTTON_B | BUTTON_C)

void game_init(void);
void game_newGame(void);
void game_retry(void);                       /* Tentar novamente apos Game Over */
const char *game_objective(u8 idx);
void game_readPad(void);
void game_addScore(u32 pts);
void game_playSfx(u8 id);
void game_playMusic(u8 id);
LevelResult game_playLevel(u8 idx);

#endif

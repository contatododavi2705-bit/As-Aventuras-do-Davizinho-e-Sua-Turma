#include "menus.h"
#include "levels.h"

/* limpa tudo e prepara uma tela de menu com fundo (cor 0 da PAL0) 'backdrop' */
static void screenInit(u16 backdrop)
{
    VDP_setEnable(FALSE);
    SPR_reset();
    VDP_setWindowVPos(FALSE, 0);
    VDP_setTextPlane(BG_A);
    VDP_clearPlane(BG_A, TRUE);
    VDP_clearPlane(BG_B, TRUE);
    VDP_clearPlane(WINDOW, TRUE);
    VDP_setHorizontalScroll(BG_A, 0);
    VDP_setHorizontalScroll(BG_B, 0);
    VDP_setVerticalScroll(BG_A, 0);
    VDP_setVerticalScroll(BG_B, 0);
    PAL_setColor(0, backdrop);
    PAL_setColor(15, C3(7, 7, 7));
    PAL_setPalette(PAL_DAVI, spr_davi.palette->data, CPU);
    PAL_setPalette(PAL_ENT, spr_items.palette->data, CPU);
}

static void drawNum(u32 v, u16 x, u16 y, s16 digits)
{
    char buf[12];
    uintToStr(v, buf, digits);
    VDP_drawText(buf, x, y);
}

static bool anyButton(void)
{
    return PRESSED(BUTTON_START) || PRESSED(BUTTON_A) || PRESSED(BUTTON_B) || PRESSED(BUTTON_C);
}

/* espera 'frames' quadros; retorna TRUE se o jogador apertou um botao (apos 20 quadros) */
static bool waitFrames(u16 frames)
{
    u16 t;
    for (t = 0; t < frames; t++)
    {
        game_readPad();
        SPR_update();
        SYS_doVBlankProcess();
        if (t > 20 && anyButton()) return TRUE;
    }
    return FALSE;
}

/* "PRESSIONE START" piscando; so aceita depois de 30 quadros */
static void waitStart(u16 y, u16 x)
{
    u16 t = 0;
    gPad = gPadPrev = 0;
    while (TRUE)
    {
        game_readPad();
        VDP_drawText((t & 32) ? "                " : "PRESSIONE  START", x, y);
        SPR_update();
        SYS_doVBlankProcess();
        t++;
        if (t > 30 && anyButton()) return;
    }
}

/* menu de duas opcoes; retorna 0 ou 1 */
static u8 choose2(const char *a, const char *b, u16 x, u16 y)
{
    u8 sel = 0;
    u16 t = 0;
    VDP_drawText(a, x + 2, y);
    VDP_drawText(b, x + 2, y + 2);
    gPad = gPadPrev = 0;
    while (TRUE)
    {
        game_readPad();
        if (PRESSED(BUTTON_UP) || PRESSED(BUTTON_DOWN)) { sel ^= 1; game_playSfx(SFX_COIN); }
        VDP_drawText(sel == 0 ? ">" : " ", x, y);
        VDP_drawText(sel == 1 ? ">" : " ", x, y + 2);
        SPR_update();
        SYS_doVBlankProcess();
        t++;
        if (t > 30 && anyButton()) { game_playSfx(SFX_CHECK); return sel; }
    }
}

/* ------------------------------------------------------------------------ */
u8 menus_title(void)
{
    u8 sel = 0;
    Sprite *davi;
    u16 t = 0;

    gScreen = SCR_TITLE;
    screenInit(C3(2, 3, 6));      /* cor 0 da imagem e transparente: usa o tom do ceu */
    VDP_drawImageEx(BG_B, &img_title, TILE_ATTR_FULL(PAL_BG, FALSE, FALSE, FALSE, TILE_TITLE), 0, 0, TRUE, TRUE);
    davi = SPR_addSprite(&spr_davi, 148, 119, TILE_ATTR(PAL_DAVI, FALSE, FALSE, FALSE));
    if (davi) SPR_setAnim(davi, 0);
    VDP_drawText("NOVO JOGO", 15, 21);
    VDP_drawText("SELECIONAR FASE", 15, 23);
    VDP_drawText("DAVI E SUA TURMA", 12, 26);
    game_playMusic(MUS_FASE1);
    VDP_setEnable(TRUE);
    gPad = gPadPrev = 0;

    while (TRUE)
    {
        game_readPad();
        if (PRESSED(BUTTON_UP) || PRESSED(BUTTON_DOWN)) { sel ^= 1; game_playSfx(SFX_COIN); }
        VDP_drawText(sel == 0 ? ">" : " ", 13, 21);
        VDP_drawText(sel == 1 ? ">" : " ", 13, 23);
        VDP_drawText((t & 48) ? "     " : "START", 33, 21);
        if (anyButton())
        {
            game_playSfx(SFX_CHECK);
            return sel;
        }
        SPR_update();
        SYS_doVBlankProcess();
        t++;
    }
}

u8 menus_levelSelect(void)
{
    u8 sel = 0, i;

    gScreen = SCR_SELECT;
    screenInit(C3(0, 1, 3));
    VDP_drawText("SELECIONE A FASE", 12, 3);
    for (i = 0; i < NUM_LEVELS; i++)
        VDP_drawText(i <= gGame.unlocked ? gLevels[i].name : "FASE ? - BLOQUEADA", 6, 8 + i * 2);
    VDP_drawText("CIMA/BAIXO: ESCOLHE   START: JOGA", 3, 22);
    VDP_setEnable(TRUE);
    gPad = gPadPrev = 0;

    while (TRUE)
    {
        game_readPad();
        if (PRESSED(BUTTON_UP) && sel > 0) { sel--; game_playSfx(SFX_COIN); }
        if (PRESSED(BUTTON_DOWN) && sel < gGame.unlocked) { sel++; game_playSfx(SFX_COIN); }
        for (i = 0; i < NUM_LEVELS; i++) VDP_drawText(i == sel ? ">" : " ", 4, 8 + i * 2);
        if (anyButton())
        {
            game_playSfx(SFX_CHECK);
            return sel;
        }
        SYS_doVBlankProcess();
    }
}

void menus_levelIntro(u8 idx)
{
    gScreen = SCR_INTRO;
    screenInit(idx == NUM_LEVELS - 1 ? C3(2, 0, 3) : C3(0, 1, 3));
    if (idx == NUM_LEVELS - 1)
    {
        VDP_drawText("*** DESAFIO FINAL ***", 9, 5);
        VDP_drawText("A ULTIMA FASE DA AVENTURA!", 7, 7);
    }
    else
    {
        VDP_drawText("FASE", 17, 5);
        drawNum(idx + 1, 22, 5, 1);
    }
    VDP_drawText(gLevels[idx].name, 5, 10);
    VDP_drawText("ALCANCE A BANDEIRA NO FIM DA FASE", 3, 13);
    VDP_drawText("PARA CONCLUIR!", 13, 15);
    VDP_drawText("A: ESTRELA   B/C: PULAR", 8, 19);
    VDP_setEnable(TRUE);
    waitStart(23, 12);
}

void menus_levelComplete(u8 idx)
{
    Sprite *davi;

    gScreen = SCR_COMPLETE;
    screenInit(C3(0, 1, 3));
    VDP_drawText("FASE CONCLUIDA!", 12, 4);
    VDP_drawText(gLevels[idx].name, 5, 7);
    VDP_drawText("PONTOS:", 12, 11);  drawNum(gGame.score, 20, 11, 6);
    VDP_drawText("VIDAS: ", 12, 13);  drawNum(gGame.lives, 20, 13, 1);
    VDP_drawText("MOEDAS:", 12, 15);  drawNum(gGame.coins, 20, 15, 2);
    if (idx + 1 < NUM_LEVELS)
    {
        VDP_drawText("PROXIMA:", 4, 18);
        VDP_drawText(gLevels[idx + 1].name, 4, 19);
    }
    davi = SPR_addSprite(&spr_davi, 148, 180, TILE_ATTR(PAL_DAVI, FALSE, FALSE, FALSE));
    if (davi) SPR_setAnim(davi, 6);
    VDP_setEnable(TRUE);
    game_playMusic(MUS_VITORIA);
    waitStart(24, 12);
    XGM_stopPlay();
}

u8 menus_gameOver(void)
{
    u8 r;
    gScreen = SCR_GAMEOVER;
    screenInit(0);
    VDP_drawText("GAME OVER", 15, 6);
    VDP_drawText("PONTOS:", 12, 10);
    drawNum(gGame.score, 20, 10, 6);
    VDP_drawText("A TURMA ACREDITA EM VOCE, DAVI!", 4, 13);
    VDP_setEnable(TRUE);
    game_playMusic(MUS_GAMEOVER);
    r = choose2("TENTAR NOVAMENTE", "VOLTAR AO MENU", 11, 17);
    XGM_stopPlay();
    return r;
}

/* ------------------------------------------------------------------------
   Final verdadeiro: a Turma comemora com o Davi; depois PARABENS.
   ------------------------------------------------------------------------ */
static void speak(const char *text)
{
    VDP_clearText(0, 18, 40);
    VDP_clearText(0, 19, 40);
    VDP_drawText(text, 1, 18);
    waitFrames(170);
}

void menus_ending(void)
{
    Sprite *s;
    u8 i;

    gScreen = SCR_ENDING;
    screenInit(C3(2, 0, 3));
    VDP_drawText("A BANDEIRA DA TURMA!", 10, 4);
    s = SPR_addSprite(&spr_davi, 148, 150, TILE_ATTR(PAL_DAVI, FALSE, FALSE, FALSE));
    if (s) SPR_setAnim(s, 6);
    for (i = 0; i < 4; i++)
    {
        s = SPR_addSprite(&spr_turma, i < 2 ? 84 + i * 36 : 196 + (i - 2) * 36, 150, TILE_ATTR(PAL_ENT, FALSE, FALSE, FALSE));
        if (s) SPR_setAnim(s, i);
    }
    VDP_setEnable(TRUE);
    game_playMusic(MUS_VITORIA);
    waitFrames(60);
    speak("MIGUEL: VOCE CONSEGUIU, DAVI!");
    speak("AGATA: SEM VOCE NADA SERIA IGUAL!");
    speak("MAXWELL: A TURMA ESTA SEGURA!");
    speak("MARIA F.: VAMOS COMEMORAR JUNTOS!");

    VDP_clearPlane(BG_A, TRUE);
    VDP_drawText("PARABENS!", 15, 6);
    VDP_drawText("VOCE COMPLETOU AS", 11, 9);
    VDP_drawText("AVENTURAS DO DAVIZINHO!", 9, 11);
    VDP_drawText("PONTOS FINAIS:", 8, 15);
    drawNum(gGame.score, 23, 15, 6);
    waitFrames(420);
    XGM_stopPlay();
}

static const char *const creditsPages[][6] =
{
    { "AS AVENTURAS DO DAVIZINHO", "DAVI E SUA TURMA", "", "UM JOGO PARA SEGA MEGA DRIVE", NULL },
    { "PERSONAGENS", "", "DAVI    AGATA", "MARIA FRANCISCA", "MAXWELL    MIGUEL", NULL },
    { "PROGRAMACAO E ARTE", "", "ESCRITO EM C COM O SGDK", "ARTE PIXEL GERADA POR SCRIPT", NULL },
    { "OBRIGADO POR JOGAR!", "", "A AVENTURA CONTINUA...", NULL }
};

void menus_credits(void)
{
    u8 p, l;

    gScreen = SCR_CREDITS;
    screenInit(C3(0, 0, 2));
    VDP_setEnable(TRUE);
    game_playMusic(MUS_FASE2);
    for (p = 0; p < 4; p++)
    {
        VDP_clearPlane(BG_A, TRUE);
        for (l = 0; creditsPages[p][l] != NULL; l++)
        {
            const char *t = creditsPages[p][l];
            u16 len = 0;
            while (t[len]) len++;
            VDP_drawText(t, (40 - len) / 2, 8 + l * 2);
        }
        waitFrames(300);
    }
    XGM_stopPlay();
}

u8 menus_endChoice(void)
{
    u8 r;
    gScreen = SCR_ENDCHOICE;
    screenInit(C3(0, 1, 3));
    VDP_drawText("FIM DE JOGO", 14, 6);
    VDP_drawText("OBRIGADO POR JOGAR!", 10, 9);
    VDP_setEnable(TRUE);
    r = choose2("VOLTAR AO TITULO", "JOGAR NOVAMENTE", 11, 14);
    return r;
}

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gerador de assets de "As Aventuras do Davizinho" (SEGA Mega Drive / SGDK).

Gera, a partir do zero (sem depender de arquivos externos):
  res/sprites/davi.png, enemies.png, items.png, goal.png, turma.png
  res/tiles/terrain.png, bg.png
  res/backgrounds/title.png
  res/audio/fase1..5.vgm, vitoria.vgm, gameover.vgm   (musica PSG)
  res/audio/*.wav                                      (efeitos 8-bit 14 kHz)

Requisitos: Python 3 + Pillow  (pip install pillow)
Uso:        python tools/gerar_assets.py

Todas as imagens sao PNG indexados de 16 cores (indice 0 = transparente),
com componentes de cor multiplos de 32 (compativeis com a paleta de 9 bits
do Mega Drive), prontos para o rescomp do SGDK.
"""
import math
import os
import random
import struct
import wave

from PIL import Image, ImageDraw, ImageFont

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(RAIZ, "res")


# ----------------------------------------------------------------------------
# utilitarios
# ----------------------------------------------------------------------------
def cor(r, g, b):
    """Cor em 3 bits por canal (0..7) -> RGB 8 bits multiplo de 32."""
    return (r * 32, g * 32, b * 32)


def paleta_plana(lista):
    lista = list(lista) + [(0, 0, 0)] * (16 - len(lista))
    plana = []
    for c in lista[:16]:
        plana.extend(c)
    return plana


def nova(w, h, pal):
    im = Image.new("P", (w, h), 0)
    im.putpalette(paleta_plana(pal))
    return im


def salvar(im, *partes):
    caminho = os.path.join(RES, *partes)
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    im.save(caminho)
    print("gerado:", os.path.relpath(caminho, RAIZ))


def contorno(im, idx=1):
    """Contorno de 1 px (indice idx) em volta dos pixels opacos."""
    w, h = im.size
    px = im.load()
    novos = []
    for y in range(h):
        for x in range(w):
            if px[x, y] != 0:
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and px[nx, ny] != 0:
                    novos.append((x, y))
                    break
    for x, y in novos:
        px[x, y] = idx


# ----------------------------------------------------------------------------
# paletas
# ----------------------------------------------------------------------------
PAL_DAVI = [cor(0, 0, 0), cor(1, 0, 2), cor(7, 5, 4), cor(6, 3, 3), cor(4, 2, 1), cor(2, 1, 0),
            cor(1, 3, 7), cor(0, 2, 5), cor(1, 1, 4), cor(0, 0, 3), cor(7, 7, 7), cor(4, 4, 5),
            cor(0, 0, 1), cor(6, 1, 1), cor(7, 3, 3), cor(7, 7, 7)]

# paleta comum a inimigos, itens, bandeira e personagens da turma (PAL3)
PAL_ENT = [cor(0, 0, 0), cor(1, 0, 1), cor(7, 7, 7), cor(7, 7, 1), cor(7, 4, 0), cor(6, 0, 1),
           cor(3, 6, 1), cor(1, 4, 1), cor(5, 3, 1), cor(3, 1, 0), cor(7, 3, 5), cor(7, 5, 4),
           cor(1, 3, 7), cor(4, 4, 5), cor(0, 0, 1), cor(7, 6, 3)]

# paleta de pre-visualizacao do terreno (no jogo, cada fase troca as cores via C)
PAL_TERRENO = [cor(3, 5, 7), cor(1, 0, 1), cor(3, 6, 1), cor(1, 4, 1), cor(6, 4, 2), cor(4, 2, 1),
               cor(7, 5, 2), cor(4, 2, 1), cor(2, 6, 2), cor(1, 4, 1), cor(5, 5, 6), cor(3, 3, 4),
               cor(7, 1, 1), cor(7, 7, 1), cor(1, 3, 7), cor(7, 7, 7)]

PAL_BG = [cor(0, 0, 0), cor(2, 5, 3), cor(1, 4, 2), cor(7, 7, 7), cor(6, 6, 7), cor(0, 1, 3), cor(0, 0, 1)] + [cor(0, 0, 0)] * 9

PAL_TITULO = [cor(2, 3, 6), cor(3, 4, 7), cor(4, 5, 7), cor(5, 6, 7), cor(7, 7, 2), cor(2, 5, 3),
              cor(1, 4, 1), cor(0, 3, 1), cor(1, 0, 2), cor(7, 7, 1), cor(7, 4, 0), cor(6, 1, 1),
              cor(0, 1, 3), cor(7, 7, 7), cor(1, 2, 5), cor(4, 2, 1)]


# ----------------------------------------------------------------------------
# DAVI  (celula 24x32 px = 3x4 tiles; 7 animacoes x 6 quadros)
# ----------------------------------------------------------------------------
ESTRELA = [
    "..X..",
    ".XXX.",
    "XXXXX",
    ".XXX.",
    ".X.X.",
]

# (esq_dx, esq_lift, dir_dx, dir_lift)
PASSOS_ANDAR = [(2, 0, -2, 1), (1, 0, -1, 0), (0, 0, 0, 0), (-2, 1, 2, 0), (-1, 0, 1, 0), (0, 0, 0, 0)]
PASSOS_CORRER = [(3, 0, -3, 2), (1, 0, -1, 3), (-2, 1, 2, 0), (-3, 2, 3, 0), (-1, 3, 1, 1), (2, 1, -2, 0)]


def davi_quadro(anim, f):
    im = nova(24, 32, PAL_DAVI)
    d = ImageDraw.Draw(im)

    def R(x0, y0, x1, y1, c):
        d.rectangle([x0, y0, x1, y1], fill=c)

    def P(x, y, c):
        if 0 <= x < 24 and 0 <= y < 32:
            im.putpixel((x, y), c)

    ph = f % 6
    bob, lean = 0, 0
    legs = (0, 0, 0, 0)
    mao_e, mao_d = (4, 26), (19, 26)
    olhos, boca = "normal", "normal"

    if anim == 0:        # parado
        bob = 1 if ph >= 3 else 0
        mao_e, mao_d = (5, 26 + bob), (18, 26 + bob)
    elif anim == 1:      # andando
        legs = PASSOS_ANDAR[ph]
        bob = 1 if ph in (1, 4) else 0
        sw = legs[0]
        mao_e, mao_d = (5 - sw, 25), (18 + sw, 25)
    elif anim == 2:      # correndo
        legs = PASSOS_CORRER[ph]
        lean = 1
        bob = 1 if ph in (1, 4) else 0
        sw = legs[0]
        mao_e, mao_d = (4 - sw, 23), (20 + sw, 23)
    elif anim == 3:      # pulando
        legs = (2, 2, -2, 3)
        mao_e, mao_d = (3, 11 - (ph % 2)), (20, 11 - (ph % 2))
        boca = "aberta"
    elif anim == 4:      # caindo
        legs = (3, 0, -3, 0)
        mao_e, mao_d = (2, 18 + (ph % 2)), (21, 18 + (ph % 2))
        boca = "aberta"
    elif anim == 5:      # dano
        legs = (3, 0, -3, 0)
        lean = -1
        mao_e, mao_d = (3, 12 + (ph % 2)), (20, 12 + (ph % 2))
        olhos, boca = "x", "aberta"
    elif anim == 6:      # comemorando
        bob = ph % 2
        legs = (1, 0, -1, 0) if ph % 2 == 0 else (0, 1, 0, 1)
        mao_e, mao_d = (4, 7 + (ph % 2) * 2), (19, 9 - (ph % 2) * 2)
        olhos, boca = "feliz", "sorriso"

    oy = bob
    # pernas
    for x0, dx, lift in ((8, legs[0], legs[1]), (13, legs[2], legs[3])):
        foot = 30 - lift
        if foot - 2 >= 28:
            R(x0, 28, x0 + 2, foot - 2, 2)
        R(x0 - 1 + dx, foot - 1, x0 + 3 + dx, foot, 10)
        R(x0 - 1 + dx, foot, x0 + 3 + dx, foot, 11)
    # tronco + shorts
    R(7 + lean, 18 + oy, 16 + lean, 25 + oy, 6)
    R(16 + lean, 18 + oy, 16 + lean, 25 + oy, 7)
    R(7 + lean, 25 + oy, 16 + lean, 25 + oy, 7)
    R(7 + lean, 26 + oy, 16 + lean, 27 + oy, 8)
    R(7 + lean, 27 + oy, 16 + lean, 27 + oy, 9)
    for j, linha in enumerate(ESTRELA):
        for i, ch in enumerate(linha):
            if ch == "X":
                P(10 + lean + i, 19 + oy + j, 15)
    # bracos
    for ombro, mao in (((6 + lean, 19 + oy), mao_e), ((17 + lean, 19 + oy), mao_d)):
        d.line([ombro, (mao[0] + lean, mao[1] + oy if anim not in (3, 4, 5, 6) else mao[1])], fill=2, width=2)
        R(ombro[0] - 1, ombro[1], ombro[0], ombro[1] + 1, 6)
        P(mao[0] + lean, (mao[1] + oy) if anim not in (3, 4, 5, 6) else mao[1], 3)
    # cabeca
    hx = lean
    R(7 + hx, 8 + oy, 16 + hx, 17 + oy, 2)
    R(6 + hx, 4 + oy, 17 + hx, 8 + oy, 4)                      # cabelo base
    for (a, b, c) in ((6, 7, 9), (9, 11, 13), (13, 15, 17)):   # espetos
        d.polygon([(a + hx, 4 + oy), (b + hx, 1 + oy), (c + hx, 4 + oy)], fill=4)
    R(6 + hx, 8 + oy, 6 + hx, 11 + oy, 5)
    R(17 + hx, 8 + oy, 17 + hx, 11 + oy, 5)
    R(7 + hx, 4 + oy, 16 + hx, 4 + oy, 5)
    # rosto
    if olhos == "normal":
        R(9 + hx, 12 + oy, 9 + hx, 13 + oy, 12)
        R(14 + hx, 12 + oy, 14 + hx, 13 + oy, 12)
    elif olhos == "x":
        for ex in (9, 14):
            for dx, dy in ((-1, -1), (1, -1), (0, 0), (-1, 1), (1, 1)):
                P(ex + dx + hx, 12 + dy + oy, 12)
    else:  # feliz ^ ^
        for ex in (9, 14):
            P(ex - 1 + hx, 13 + oy, 12)
            P(ex + hx, 12 + oy, 12)
            P(ex + 1 + hx, 13 + oy, 12)
    P(8 + hx, 15 + oy, 14)
    P(15 + hx, 15 + oy, 14)
    if boca == "normal":
        for (mx, my) in ((9, 14), (10, 15), (11, 15), (12, 15), (13, 15), (14, 14)):
            P(mx + hx, my + oy, 13)
    elif boca == "aberta":
        R(11 + hx, 15 + oy, 12 + hx, 16 + oy, 13)
    else:  # sorriso grande
        R(9 + hx, 14 + oy, 14 + hx, 16 + oy, 13)
        R(10 + hx, 14 + oy, 13 + hx, 14 + oy, 15)
    contorno(im, 1)
    return im


def gerar_davi():
    im = nova(6 * 24, 7 * 32, PAL_DAVI)
    for anim in range(7):
        for f in range(6):
            im.paste(davi_quadro(anim, f), (f * 24, anim * 32))
    salvar(im, "sprites", "davi.png")


# ----------------------------------------------------------------------------
# INIMIGOS (celula 16x16; linha 0 = caramujo, linha 1 = abelha)
# ----------------------------------------------------------------------------
def caramujo(f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    w = f % 2
    d.rectangle([1, 11 + w, 12, 14], fill=6)
    d.rectangle([1, 14, 12, 14], fill=7)
    d.rectangle([10, 6, 14, 13], fill=6)
    d.ellipse([2, 1, 10, 11], fill=8)
    d.ellipse([4, 3, 8, 9], outline=9)
    im.putpixel((6, 6), 9)
    d.line([(11, 6), (11 - w, 3)], fill=7)
    d.line([(14, 6), (14 + 0, 3 + w)], fill=7)
    im.putpixel((11 - w, 2), 14)
    im.putpixel((14, 2 + w), 14)
    im.putpixel((13, 9), 14)
    im.putpixel((12, 9), 2)
    contorno(im, 1)
    return im


def abelha(f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    if f % 2 == 0:
        d.ellipse([4, 0, 8, 5], fill=2)
        d.ellipse([8, 1, 12, 5], fill=2)
    else:
        d.ellipse([5, 3, 9, 6], fill=2)
        d.ellipse([8, 3, 12, 6], fill=2)
    d.ellipse([3, 6, 12, 13], fill=3)
    d.rectangle([6, 7, 6, 12], fill=14)
    d.rectangle([9, 7, 9, 12], fill=14)
    d.ellipse([11, 6, 14, 10], fill=4)
    im.putpixel((13, 7), 14)
    d.polygon([(0, 10), (3, 9), (3, 11)], fill=14)
    contorno(im, 1)
    return im


def gerar_inimigos():
    im = nova(64, 32, PAL_ENT)
    for f in range(4):
        im.paste(caramujo(f), (f * 16, 0))
        im.paste(abelha(f), (f * 16, 16))
    salvar(im, "sprites", "enemies.png")


# ----------------------------------------------------------------------------
# ITENS (celula 16x16; 6 linhas x 4 quadros)
# ----------------------------------------------------------------------------
def item_moeda(f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    w = (10, 6, 2, 6)[f]
    d.ellipse([8 - w // 2, 2, 8 + w // 2 - (1 if w > 2 else 0), 13], fill=4)
    if w >= 6:
        d.ellipse([8 - w // 2 + 1, 3, 8 + w // 2 - 2, 12], fill=3)
        im.putpixel((8, 5), 2)
        d.line([(8, 6), (8, 10)], fill=4)
    contorno(im, 1)
    return im


def item_coracao(f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    oy = f % 2
    d.ellipse([2, 3 + oy, 8, 9 + oy], fill=5)
    d.ellipse([7, 3 + oy, 13, 9 + oy], fill=5)
    d.polygon([(2, 7 + oy), (13, 7 + oy), (7, 14 + oy)], fill=5)
    im.putpixel((4, 5 + oy), 10)
    im.putpixel((5, 4 + oy), 10)
    contorno(im, 1)
    return im


def item_vida(f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    d.polygon([(8, 1), (10, 6), (15, 6), (11, 9), (13, 14), (8, 11), (3, 14), (5, 9), (1, 6), (6, 6)], fill=3)
    d.ellipse([6, 6, 9, 9], fill=6)
    if f % 2:
        im.putpixel((7, 3), 2)
        im.putpixel((8, 4), 2)
    contorno(im, 1)
    return im


def item_checkpoint(ativo, f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    d.rectangle([7, 1, 8, 15], fill=13)
    off = f % 2
    if ativo:
        d.polygon([(9, 2), (15, 4 + off), (9, 8)], fill=5)
        im.putpixel((11, 4), 2)
    else:
        d.polygon([(9, 2), (14, 4), (9, 7)], fill=13)
    contorno(im, 1)
    return im


def item_estrela(f):
    im = nova(16, 16, PAL_ENT)
    d = ImageDraw.Draw(im)
    w = (5, 3, 1, 3)[f]
    d.polygon([(8, 3), (8 + w, 8), (8, 13), (8 - w, 8)], fill=3)
    d.polygon([(3, 8), (8, 8 - w), (13, 8), (8, 8 + w)], fill=15)
    im.putpixel((8, 8), 2)
    contorno(im, 1)
    return im


def gerar_itens():
    im = nova(64, 96, PAL_ENT)
    for f in range(4):
        im.paste(item_moeda(f), (f * 16, 0))
        im.paste(item_coracao(f), (f * 16, 16))
        im.paste(item_vida(f), (f * 16, 32))
        im.paste(item_checkpoint(False, f), (f * 16, 48))
        im.paste(item_checkpoint(True, f), (f * 16, 64))
        im.paste(item_estrela(f), (f * 16, 80))
    salvar(im, "sprites", "items.png")


def gerar_bandeira():
    im = nova(64, 32, PAL_ENT)
    for f in range(4):
        q = nova(16, 32, PAL_ENT)
        d = ImageDraw.Draw(q)
        d.rectangle([2, 2, 3, 29], fill=13)
        d.ellipse([1, 0, 4, 3], fill=3)
        a, b = (0, 1, 0, -1)[f], (1, 0, -1, 0)[f]
        d.polygon([(4, 4), (14, 4 + a), (14, 13 + b), (4, 14)], fill=5)
        d.polygon([(8, 7), (9, 9), (11, 9), (9, 11), (10, 13 + b), (8, 11), (6, 13), (7, 9), (5, 9)], fill=3)
        d.rectangle([0, 28, 6, 31], fill=9)
        d.rectangle([0, 28, 6, 28], fill=8)
        contorno(q, 1)
        im.paste(q, (f * 16, 0))
    salvar(im, "sprites", "goal.png")


# ----------------------------------------------------------------------------
# TURMA (celula 16x32: Agata, Maria Francisca, Maxwell, Miguel)
# ----------------------------------------------------------------------------
def personagem(quem, f):
    q = nova(16, 32, PAL_ENT)
    d = ImageDraw.Draw(q)
    oy = f % 2

    def R(x0, y0, x1, y1, c):
        d.rectangle([x0, y0, x1, y1], fill=c)

    # pernas e sapatos
    R(5, 24 + oy, 6, 28, 11)
    R(9, 24 + oy, 10, 28, 11)
    R(4, 29, 7, 30, 14)
    R(8, 29, 11, 30, 14)
    if quem == 0:        # Agata: vestido rosa, cabelo longo castanho, laco vermelho
        R(2, 14 + oy, 13, 22 + oy, 10)
        R(3, 22 + oy, 12, 24 + oy, 10)
        R(3, 5 + oy, 12, 14 + oy, 9)
        R(4, 7 + oy, 11, 13 + oy, 11)
        R(2, 10 + oy, 3, 20 + oy, 9)
        R(12, 10 + oy, 13, 20 + oy, 9)
        R(6, 1 + oy, 9, 3 + oy, 5)
    elif quem == 1:      # Maria Francisca: cachos laranja, vestido amarelo
        R(3, 14 + oy, 12, 23 + oy, 3)
        R(4, 6 + oy, 11, 13 + oy, 11)
        R(3, 3 + oy, 12, 7 + oy, 4)
        d.ellipse([0, 7 + oy, 3, 11 + oy], fill=4)
        d.ellipse([12, 7 + oy, 15, 11 + oy], fill=4)
        R(7, 1 + oy, 8, 2 + oy, 12)
    elif quem == 2:      # Maxwell: cabelo preto, oculos, camiseta verde
        R(4, 14 + oy, 11, 23 + oy, 6)
        R(4, 6 + oy, 11, 13 + oy, 11)
        R(4, 3 + oy, 11, 7 + oy, 14)
        R(5, 9 + oy, 7, 10 + oy, 2)
        R(8, 9 + oy, 10, 10 + oy, 2)
        d.rectangle([5, 9 + oy, 7, 10 + oy], outline=14)
        d.rectangle([8, 9 + oy, 10, 10 + oy], outline=14)
        R(4, 24 + oy, 11, 24 + oy, 12)
    else:                # Miguel: cabelo ruivo espetado, camiseta vermelha
        R(4, 14 + oy, 11, 23 + oy, 5)
        R(4, 6 + oy, 11, 13 + oy, 11)
        R(4, 4 + oy, 11, 7 + oy, 4)
        for x in (4, 7, 10):
            d.polygon([(x, 4 + oy), (x + 1, 1 + oy), (x + 2, 4 + oy)], fill=4)
        R(4, 24 + oy, 11, 24 + oy, 8)
    # rosto
    if quem != 2:
        q.putpixel((6, 9 + oy), 14)
        q.putpixel((9, 9 + oy), 14)
    else:
        q.putpixel((6, 9 + oy), 14)
        q.putpixel((9, 9 + oy), 14)
    R(7, 12 + oy, 8, 12 + oy, 5)
    # bracinhos
    R(2 if quem != 0 else 1, 15 + oy, 3 if quem != 0 else 2, 21 + oy, 11)
    R(12, 15 + oy, 13, 21 + oy, 11)
    contorno(q, 1)
    return q


def gerar_turma():
    im = nova(64, 128, PAL_ENT)
    for quem in range(4):
        for f in range(4):
            im.paste(personagem(quem, f), (f * 16, quem * 32))
    salvar(im, "sprites", "turma.png")


# ----------------------------------------------------------------------------
# TERRENO: 16 metatiles 16x16, gravados como 64 tiles 8x8 consecutivos
# (TL, TR, BL, BR) em uma faixa de 512x8 px. Indice do metatile = tipo do mapa.
# ----------------------------------------------------------------------------
def metatile(m):
    im = nova(16, 16, PAL_TERRENO)
    d = ImageDraw.Draw(im)
    rnd = random.Random(m * 77 + 3)

    def R(x0, y0, x1, y1, c):
        d.rectangle([x0, y0, x1, y1], fill=c)

    if m == 1:      # grama
        R(0, 0, 15, 15, 4)
        for _ in range(14):
            im.putpixel((rnd.randrange(16), rnd.randrange(7, 16)), 5)
        R(0, 0, 15, 3, 2)
        R(0, 0, 15, 0, 3)
        for x in range(0, 16, 2):
            R(x, 4, x, 5 + (x // 2) % 2, 3)
    elif m == 2:    # terra
        R(0, 0, 15, 15, 4)
        for _ in range(22):
            x, y = rnd.randrange(15), rnd.randrange(16)
            R(x, y, x + 1, y, 5)
    elif m == 3:    # pedra
        R(0, 0, 15, 15, 10)
        R(0, 7, 15, 7, 11)
        R(0, 15, 15, 15, 11)
        R(7, 0, 7, 6, 11)
        R(3, 8, 3, 14, 11)
        R(11, 8, 11, 14, 11)
        R(0, 0, 15, 0, 15)
    elif m == 4:    # prancha de madeira (so o topo e solido)
        R(0, 0, 15, 5, 6)
        R(0, 5, 15, 5, 7)
        R(5, 1, 5, 4, 7)
        R(10, 1, 10, 4, 7)
        R(2, 2, 2, 2, 11)
        R(13, 2, 13, 2, 11)
        R(0, 0, 15, 0, 15)
    elif m == 5:    # espinhos
        R(0, 14, 15, 15, 11)
        for i in range(3):
            x0 = 1 + i * 5
            d.polygon([(x0, 14), (x0 + 2, 6), (x0 + 4, 14)], fill=10)
            im.putpixel((x0 + 2, 7), 15)
            d.line([(x0, 14), (x0 + 2, 6)], fill=11)
    elif m == 6:    # arbusto
        d.ellipse([0, 5, 9, 15], fill=8)
        d.ellipse([5, 3, 15, 15], fill=8)
        for y in range(10, 16):
            for x in range(16):
                if im.getpixel((x, y)) == 8 and rnd.random() < 0.35:
                    im.putpixel((x, y), 9)
        for (x, y) in ((4, 9), (10, 7), (12, 11)):
            im.putpixel((x, y), 12)
    elif m == 7:    # flores
        d.line([(4, 15), (4, 9)], fill=3)
        d.line([(11, 15), (11, 6)], fill=3)
        d.ellipse([2, 6, 6, 10], fill=12)
        im.putpixel((4, 8), 13)
        d.ellipse([9, 3, 13, 7], fill=14)
        im.putpixel((11, 5), 15)
    elif m == 8:    # tronco (cenario)
        R(0, 0, 15, 15, 7)
        for x in (2, 6, 9, 13):
            R(x, 0, x, 15, 6)
        for _ in range(8):
            im.putpixel((rnd.randrange(16), rnd.randrange(16)), 1)
    elif m == 9:    # folhagem (plataforma)
        R(0, 0, 15, 3, 8)
        R(0, 4, 15, 5, 9)
        for x in range(0, 16, 4):
            R(x + 1, 6, x + 2, 6, 9)
        R(0, 0, 15, 0, 2)
    elif m == 10:   # cerca
        for x in (1, 7, 13):
            R(x, 3, x + 2, 15, 6)
            R(x, 3, x + 2, 3, 7)
        R(0, 6, 15, 7, 7)
        R(0, 11, 15, 12, 7)
    elif m == 11:   # banco
        R(1, 4, 14, 6, 7)
        R(1, 4, 14, 4, 6)
        R(0, 9, 15, 10, 6)
        R(2, 11, 3, 15, 7)
        R(12, 11, 13, 15, 7)
    elif m == 12:   # bloco de brinquedo
        R(0, 0, 15, 15, 12)
        R(3, 3, 12, 12, 13)
        R(5, 5, 10, 10, 14)
        d.rectangle([0, 0, 15, 15], outline=1)
    elif m == 13:   # placa
        R(7, 7, 8, 15, 7)
        R(1, 1, 14, 8, 6)
        d.rectangle([1, 1, 14, 8], outline=7)
        R(3, 4, 8, 5, 7)                           # seta -> (direcao da bandeira)
        d.polygon([(8, 2), (8, 7), (12, 4)], fill=7)
    elif m == 14:   # casca solida
        R(0, 0, 15, 15, 7)
        for x in (3, 7, 12):
            R(x, 0, x, 15, 6)
        d.ellipse([5, 5, 10, 10], fill=6)
        d.ellipse([6, 6, 9, 9], fill=1)
        d.rectangle([0, 0, 15, 15], outline=1)
    elif m == 15:   # copa de arvore
        R(0, 0, 15, 15, 8)
        for _ in range(9):
            x, y = rnd.randrange(13), rnd.randrange(13)
            d.ellipse([x, y, x + 3, y + 3], fill=9)
        for _ in range(8):
            im.putpixel((rnd.randrange(16), rnd.randrange(16)), 2)
    return im


def gerar_terreno():
    faixa = nova(64 * 8, 8, PAL_TERRENO)
    for m in range(16):
        mt = metatile(m)
        quadros = [(0, 0), (8, 0), (0, 8), (8, 8)]
        for q, (qx, qy) in enumerate(quadros):
            faixa.paste(mt.crop((qx, qy, qx + 8, qy + 8)), ((m * 4 + q) * 8, 0))
    salvar(faixa, "tiles", "terrain.png")


def gerar_bg():
    faixa = nova(16 * 8, 8, PAL_BG)
    for k in range(1, 8):                       # tiles 1..7: ultimas k linhas preenchidas
        t = nova(8, 8, PAL_BG)
        ImageDraw.Draw(t).rectangle([0, 8 - k, 7, 7], fill=1)
        faixa.paste(t, (k * 8, 0))
    t = nova(8, 8, PAL_BG)
    ImageDraw.Draw(t).rectangle([0, 0, 7, 7], fill=1)
    faixa.paste(t, (8 * 8, 0))
    nuvem = nova(16, 16, PAL_BG)
    d = ImageDraw.Draw(nuvem)
    d.ellipse([0, 7, 9, 15], fill=3)
    d.ellipse([4, 2, 12, 12], fill=3)
    d.ellipse([8, 6, 15, 15], fill=3)
    d.rectangle([2, 13, 13, 15], fill=4)
    for q, (qx, qy) in enumerate([(0, 0), (8, 0), (0, 8), (8, 8)]):
        faixa.paste(nuvem.crop((qx, qy, qx + 8, qy + 8)), ((9 + q) * 8, 0))
    t = nova(8, 8, PAL_BG)
    ImageDraw.Draw(t).rectangle([0, 0, 7, 7], fill=2)
    faixa.paste(t, (13 * 8, 0))
    for idx_tile, idx_cor in ((14, 5), (15, 6)):      # 14 = faixa do HUD, 15 = vazio dos buracos
        t = nova(8, 8, PAL_BG)
        ImageDraw.Draw(t).rectangle([0, 0, 7, 7], fill=idx_cor)
        faixa.paste(t, (idx_tile * 8, 0))
    salvar(faixa, "tiles", "bg.png")


# ----------------------------------------------------------------------------
# TELA DE TITULO 320x224
# ----------------------------------------------------------------------------
def texto_grande(im, txt, y, escala, cor_texto, cor_borda=8):
    fonte = ImageFont.load_default()
    m = Image.new("L", (len(txt) * 8 + 8, 16), 0)
    ImageDraw.Draw(m).text((2, 2), txt, fill=255, font=fonte)
    caixa = m.getbbox()
    if not caixa:
        return
    m = m.crop(caixa)
    m = m.resize((m.width * escala, m.height * escala), Image.NEAREST).point(lambda v: 255 if v > 127 else 0)
    x = (320 - m.width) // 2
    for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (2, 2), (-2, -2), (2, -2), (-2, 2), (0, 3), (3, 3)):
        im.paste(cor_borda, (x + dx, y + dy), m)
    im.paste(cor_texto, (x, y), m)


def gerar_titulo():
    im = nova(320, 224, PAL_TITULO)
    d = ImageDraw.Draw(im)
    for (y0, y1, c) in ((0, 40, 0), (40, 80, 1), (80, 112, 2), (112, 152, 3)):
        d.rectangle([0, y0, 319, y1 - 1], fill=c)
    d.ellipse([228, 38, 272, 82], fill=4)
    for (cx, cy) in ((30, 100), (110, 120), (190, 95), (290, 125)):
        d.ellipse([cx, cy, cx + 30, cy + 10], fill=13)
        d.ellipse([cx + 8, cy - 6, cx + 24, cy + 6], fill=13)
    far, near = [], []
    for x in range(321):
        far.append((x, 142 - int(14 * math.sin(x / 31.0) + 6 * math.sin(x / 11.0))))
        near.append((x, 150 - int(8 * math.sin(x / 19.0 + 1.0))))
    d.polygon(far + [(320, 152), (0, 152)], fill=5)
    d.polygon(near + [(320, 152), (0, 152)], fill=6)
    d.rectangle([0, 150, 319, 154], fill=7)
    # arvore (mangueira) a esquerda e direita
    for tx in (36, 276):
        d.rectangle([tx, 118, tx + 7, 152], fill=15)
        d.ellipse([tx - 22, 86, tx + 30, 126], fill=6)
        d.ellipse([tx - 14, 78, tx + 22, 112], fill=7)
        for (fx, fy) in ((tx - 8, 104), (tx + 10, 96), (tx + 16, 112)):
            d.ellipse([fx, fy, fx + 4, fy + 4], fill=10)
    # painel inferior para o menu
    d.rectangle([0, 156, 319, 223], fill=12)
    d.rectangle([0, 156, 319, 158], fill=14)
    d.rectangle([0, 220, 319, 223], fill=14)
    texto_grande(im, "AS AVENTURAS DO", 12, 2, 13)
    texto_grande(im, "DAVIZINHO", 34, 5, 9)
    texto_grande(im, "E SUA TURMA", 84, 2, 10)
    salvar(im, "backgrounds", "title.png")


# ----------------------------------------------------------------------------
# AUDIO: musica PSG (VGM) e efeitos 8 bits (WAV)
# ----------------------------------------------------------------------------
PSG_CLOCK = 3579545


def midi_para_n(m):
    while True:
        f = 440.0 * 2 ** ((m - 69) / 12.0)
        n = int(round(PSG_CLOCK / (32.0 * f)))
        if n <= 1023:
            return max(1, n)
        m += 12


MELODIA = [
    [(76, 4), (79, 4), (76, 2), (74, 2), (72, 4)],
    [(81, 4), (79, 2), (76, 2), (72, 4), (76, 4)],
    [(77, 4), (81, 4), (77, 2), (76, 2), (72, 4)],
    [(74, 4), (79, 4), (77, 2), (74, 2), (71, 4)],
    [(72, 2), (76, 2), (79, 2), (84, 2), (79, 4), (76, 4)],
    [(81, 4), (84, 4), (81, 2), (79, 2), (76, 4)],
    [(77, 2), (81, 2), (84, 2), (81, 2), (77, 4), (72, 4)],
    [(79, 4), (74, 4), (71, 4), (74, 2), (79, 2)],
]
ACORDES = [(48, (60, 64, 67)), (45, (57, 60, 64)), (41, (53, 57, 60)), (43, (55, 59, 62))] * 2


def faixa_vazia(n):
    return [None] * n


def montar_musica(transp, fpt, repeticoes=2):
    """Retorna listas por quadro: tom0, tom1, tom2 (midi, atenuacao) e ruido (atenuacao)."""
    total = 0
    for compasso in MELODIA:
        total += sum(d for _, d in compasso) * fpt
    total *= repeticoes
    t0, t1, t2, rd = faixa_vazia(total), faixa_vazia(total), faixa_vazia(total), [15] * total
    pos = 0
    for _ in range(repeticoes):
        for ci, compasso in enumerate(MELODIA):
            inicio = pos
            for nota, dur in compasso:
                n = dur * fpt
                for k in range(n):
                    att = 15 if k == n - 1 else min(9, 2 + k // 3)
                    t0[pos + k] = (nota + transp, att)
                pos += n
            raiz, tri = ACORDES[ci]
            for s in range(16):                     # semicolcheias do compasso
                base = inicio + s * fpt
                nb = raiz if s % 4 != 3 else raiz + 12
                for k in range(fpt):
                    if base + k < total:
                        t2[base + k] = (nb + transp, 4 if k < fpt - 1 else 15)
                        t1[base + k] = (tri[s % 3] + 12 + transp, 8 if k < fpt - 1 else 15)
                if s % 2 == 0:
                    for k, a in enumerate((6, 9, 12)):
                        if base + k < total:
                            rd[base + k] = a
    return t0, t1, t2, rd


def montar_curta(notas, fpt, grave):
    total = sum(d for _, d in notas) * fpt + 30
    t0, t1, t2, rd = faixa_vazia(total), faixa_vazia(total), faixa_vazia(total), [15] * total
    pos = 0
    for nota, dur in notas:
        n = dur * fpt
        for k in range(n):
            t0[pos + k] = (nota, 15 if k == n - 1 else min(9, 2 + k // 3))
            t1[pos + k] = (nota - 12, 8 if k < n - 1 else 15)
            t2[pos + k] = (grave, 5 if k < n - 1 else 15)
        pos += n
    return t0, t1, t2, rd


def escrever_vgm(caminho, faixas, loop):
    t0, t1, t2, rd = faixas
    n = len(rd)
    dados = bytearray()
    atual = [None] * 8

    def psg(b):
        dados.extend((0x50, b & 0xFF))

    for q in range(n):
        for ch, tr in enumerate((t0, t1, t2)):
            ev = tr[q]
            if ev is None:
                nota, att = None, 15
            else:
                nota, att = ev
            if nota is not None:
                N = midi_para_n(nota)
                if atual[ch] != N:
                    psg(0x80 | (ch << 5) | (N & 0x0F))
                    psg((N >> 4) & 0x3F)
                    atual[ch] = N
            if atual[ch + 4] != att:
                psg(0x90 | (ch << 5) | att)
                atual[ch + 4] = att
        if atual[3] is None:
            psg(0xE5)
            atual[3] = 1
        if atual[7] != rd[q]:
            psg(0xF0 | rd[q])
            atual[7] = rd[q]
        dados.append(0x62)
    for ch in range(4):
        psg(0x90 | (ch << 5) | 15)
    dados.append(0x66)
    cab = bytearray(0x40)
    cab[0:4] = b"Vgm "
    total_amostras = n * 735
    struct.pack_into("<I", cab, 0x04, 0x40 + len(dados) - 4)
    struct.pack_into("<I", cab, 0x08, 0x150)
    struct.pack_into("<I", cab, 0x0C, PSG_CLOCK)
    struct.pack_into("<I", cab, 0x18, total_amostras)
    if loop:
        struct.pack_into("<I", cab, 0x1C, 0x40 - 0x1C)
        struct.pack_into("<I", cab, 0x20, total_amostras)
    struct.pack_into("<I", cab, 0x24, 60)
    struct.pack_into("<H", cab, 0x28, 0x0009)
    cab[0x2A] = 16
    struct.pack_into("<I", cab, 0x34, 0x0C)
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    with open(caminho, "wb") as fh:
        fh.write(bytes(cab) + bytes(dados))
    print("gerado:", os.path.relpath(caminho, RAIZ))


def gerar_musicas():
    pasta = os.path.join(RES, "audio")
    variantes = [(0, 7), (2, 7), (-2, 8), (4, 6), (5, 7)]
    for i, (tr, fpt) in enumerate(variantes):
        escrever_vgm(os.path.join(pasta, "fase%d.vgm" % (i + 1)), montar_musica(tr, fpt), True)
    vit = [(72, 2), (76, 2), (79, 2), (84, 4), (79, 2), (84, 2), (88, 10)]
    escrever_vgm(os.path.join(pasta, "vitoria.vgm"), montar_curta(vit, 6, 48), False)
    go = [(67, 6), (64, 6), (60, 6), (55, 16)]
    escrever_vgm(os.path.join(pasta, "gameover.vgm"), montar_curta(go, 8, 43), False)


TAXA = 14000


def sintetizar(segmentos, vol=0.55):
    """segmentos: lista de (duracao, f0, f1, tipo) com tipo 'q' (quadrada) ou 'r' (ruido)."""
    amostras = []
    rnd = random.Random(5)
    fase = 0.0
    ruido = 1.0
    for dur, f0, f1, tipo in segmentos:
        n = int(TAXA * dur)
        for i in range(n):
            t = i / float(max(1, n))
            f = f0 + (f1 - f0) * t
            env = (1.0 - t) ** 0.8
            if tipo == "q":
                fase = (fase + f / TAXA) % 1.0
                v = 1.0 if fase < 0.5 else -1.0
            else:
                if i % max(1, int(TAXA / max(50.0, f))) == 0:
                    ruido = rnd.choice((-1.0, 1.0))
                v = ruido
            amostras.append(v * env * vol)
    return amostras


def gravar_wav(nome, amostras):
    dados = bytearray(int(128 + max(-1.0, min(1.0, a)) * 120) for a in amostras)
    while len(dados) % 256:
        dados.append(128)
    caminho = os.path.join(RES, "audio", nome + ".wav")
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    with wave.open(caminho, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(1)
        w.setframerate(TAXA)
        w.writeframes(bytes(dados))
    print("gerado:", os.path.relpath(caminho, RAIZ))


def gerar_sfx():
    gravar_wav("jump", sintetizar([(0.18, 300, 700, "q")]))
    gravar_wav("coin", sintetizar([(0.06, 988, 988, "q"), (0.2, 1319, 1319, "q")]))
    gravar_wav("hurt", sintetizar([(0.30, 900, 200, "r")], 0.7))
    gravar_wav("stomp", sintetizar([(0.10, 320, 100, "q"), (0.05, 400, 200, "r")]))
    gravar_wav("star", sintetizar([(0.12, 900, 1500, "q")], 0.45))
    gravar_wav("oneup", sintetizar([(0.07, 523, 523, "q"), (0.07, 659, 659, "q"), (0.07, 784, 784, "q"), (0.2, 1047, 1047, "q")]))
    gravar_wav("check", sintetizar([(0.1, 659, 659, "q"), (0.2, 880, 880, "q")]))
    gravar_wav("goal", sintetizar([(0.1, 523, 523, "q"), (0.1, 659, 659, "q"), (0.1, 784, 784, "q"), (0.1, 1047, 1047, "q"), (0.3, 1319, 1319, "q")]))
    gravar_wav("heart", sintetizar([(0.08, 784, 784, "q"), (0.18, 1047, 1047, "q")]))


# ----------------------------------------------------------------------------
if __name__ == "__main__":
    gerar_davi()
    gerar_inimigos()
    gerar_itens()
    gerar_bandeira()
    gerar_turma()
    gerar_terreno()
    gerar_bg()
    gerar_titulo()
    gerar_musicas()
    gerar_sfx()
    print("Assets gerados em", RES)

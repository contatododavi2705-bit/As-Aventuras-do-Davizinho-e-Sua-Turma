# Recursos de "As Aventuras do Davizinho" (SGDK 2.x / rescomp)
# SPRITE nome "arquivo" largura_em_tiles altura_em_tiles compressao tempo_por_quadro

SPRITE   spr_davi       "sprites/davi.png"      3 4 NONE 6
SPRITE   spr_enemies    "sprites/enemies.png"   2 2 NONE 10
SPRITE   spr_items      "sprites/items.png"     2 2 NONE 8
SPRITE   spr_goal       "sprites/goal.png"      2 4 NONE 10
SPRITE   spr_turma      "sprites/turma.png"     2 4 NONE 24

# tilesets sem otimizacao: a ordem dos tiles precisa ser preservada (4 tiles por metatile)
TILESET  ts_terrain     "tiles/terrain.png"     NONE NONE
TILESET  ts_bg          "tiles/bg.png"          NONE NONE

IMAGE    img_title      "backgrounds/title.png" NONE

XGM      mus_fase1      "audio/fase1.vgm"
XGM      mus_fase2      "audio/fase2.vgm"
XGM      mus_fase3      "audio/fase3.vgm"
XGM      mus_fase4      "audio/fase4.vgm"
XGM      mus_fase5      "audio/fase5.vgm"
XGM      mus_vitoria    "audio/vitoria.vgm"
XGM      mus_gameover   "audio/gameover.vgm"

WAV      sfx_jump       "audio/jump.wav"        XGM
WAV      sfx_coin       "audio/coin.wav"        XGM
WAV      sfx_hurt       "audio/hurt.wav"        XGM
WAV      sfx_stomp      "audio/stomp.wav"       XGM
WAV      sfx_star       "audio/star.wav"        XGM
WAV      sfx_oneup      "audio/oneup.wav"       XGM
WAV      sfx_check      "audio/check.wav"       XGM
WAV      sfx_goal       "audio/goal.wav"        XGM
WAV      sfx_heart      "audio/heart.wav"       XGM

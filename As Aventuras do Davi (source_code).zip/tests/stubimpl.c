#include <math.h>
#include <stdio.h>
#include "genesis.h"
#include "resources.h"
extern u16 botPad;
static Palette pal;
const SpriteDefinition spr_davi = {&pal}, spr_enemies = {&pal}, spr_items = {&pal}, spr_goal = {&pal}, spr_turma = {&pal};
const TileSet ts_terrain = {0}, ts_bg = {0}; const Image img_title = {0};
const u8 mus_fase1[1],mus_fase2[1],mus_fase3[1],mus_fase4[1],mus_fase5[1],mus_vitoria[1],mus_gameover[1];
const u8 sfx_jump[256],sfx_coin[256],sfx_hurt[256],sfx_stomp[256],sfx_star[256],sfx_oneup[256],sfx_check[256],sfx_goal[256],sfx_heart[256];
static Sprite pool[512]; static int np;
u16 JOY_readJoypad(u16 j){return botPad;}
Sprite* SPR_addSprite(const SpriteDefinition*d,s16 x,s16 y,u16 a){return &pool[np++%512];}
void SPR_releaseSprite(Sprite*s){} void SPR_setAnim(Sprite*s,s16 a){} void SPR_setPosition(Sprite*s,s16 x,s16 y){}
void SPR_setHFlip(Sprite*s,bool f){} void SPR_setVisibility(Sprite*s,Vis v){} void SPR_update(void){} void SPR_reset(void){} bool SPR_initEx(u16 v){return 1;}
void Z80_loadDriver(u16 a,bool b){} void XGM_setPCM(u8 a,const u8*b,u32 c){} void XGM_startPlayPCM(u8 a,u8 b,u16 c){}
void XGM_startPlay(const u8*a){} void XGM_stopPlay(void){} void XGM_pausePlay(void){} void XGM_resumePlay(void){}
void VDP_loadTileSet(const TileSet*t,u16 i,TransferMethod m){} void VDP_setTileMapXY(VDPPlane p,u16 a,u16 x,u16 y){} void VDP_clearPlane(VDPPlane p,bool w){}
void PAL_setPalette(u16 n,const u16*d,TransferMethod m){} void PAL_setColor(u16 i,u16 c){}
void VDP_setTextPlane(VDPPlane p){} void VDP_setWindowHPos(bool a,u16 b){} void VDP_setWindowVPos(bool a,u16 b){} void VDP_setEnable(bool e){}
void VDP_setHorizontalScroll(VDPPlane p,s16 v){} void VDP_setVerticalScroll(VDPPlane p,s16 v){}
void VDP_drawText(const char*t,u16 x,u16 y){} void VDP_clearText(u16 x,u16 y,u16 w){}
void uintToStr(u32 v,char*s,s16 m){sprintf(s,"%0*u",(int)m,(unsigned)v);}
bool VDP_drawImageEx(VDPPlane p,const Image*i,u16 b,u16 x,u16 y,bool l,bool d){return 1;}
s16 sinFix16(s16 a){return (s16)(sin((a&1023)*2*M_PI/1024.0)*1024);} s16 cosFix16(s16 a){return (s16)(cos((a&1023)*2*M_PI/1024.0)*1024);}

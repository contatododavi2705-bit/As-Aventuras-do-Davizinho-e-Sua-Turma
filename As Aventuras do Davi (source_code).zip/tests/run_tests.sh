#!/bin/sh
# Testes automatizados da logica do jogo (rodam no PC, sem emulador nem SGDK).
# Compila o codigo REAL de src/ contra um console simulado (tests/stub) e usa um bot
# que joga a campanha. Requer gcc e libm.  Uso: sh tests/run_tests.sh
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
SRC=src
for f in main game player enemies collectibles collision levels menus; do
  gcc -std=gnu11 -w -O1 -DDAVI_TEST -Dmain=game_main -Itests/stub -I$SRC -c $SRC/$f.c -o $OUT/$f.o
done
gcc -std=gnu11 -w -O2 -Itests/stub -I$SRC tests/stubimpl.c tests/test.c $OUT/*.o -o $OUT/runtest -lm
fail=0
for sc in 0 1 2 3 4 5; do
  echo "######## cenario $sc"
  "$OUT/runtest" $sc | grep "RESULTADO\|\[ok\]\|FALHA\|TIMEOUT" || true
  "$OUT/runtest" $sc >/dev/null 2>&1 || fail=1
done
[ $fail = 0 ] && echo "TODOS OS CENARIOS PASSARAM" || echo "HOUVE FALHAS"
exit $fail

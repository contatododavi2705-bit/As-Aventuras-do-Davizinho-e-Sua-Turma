#include "game.h"
#include "levels.h"
#include "player.h"
#include "collision.h"
#include "collectibles.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int game_main(bool hr);
static long frames, levelFrames;
bool enemies_ahead(s16 x,s16 y,s16 dir,s16 range,s16 *dist);

static long frames_dummy_unused;
static u16 plan(void);
static u16 climb(void){
  int px=gPlayer.b.x>>8, py=gPlayer.b.y>>8; bool gr=gPlayer.b.ground; static int baseY; if(gr) baseY=py; int row=baseY/16-2;
  if(row<6) return plan();                                  /* galho final: segue para a bandeira */
  int a=-1,b=-1; for(int x=0;x<lvW;x++) if(lvMap[row*lvW+x]==TL_LEAFPLAT){ if(a<0)a=x; b=x; }
  if(a<0) return plan();
  bool inside = px>=a*16+6 && px<=b*16+10; int dir = inside?0:(px<a*16+6?1:-1);
  int dist = dir>0 ? a*16+6-px : (dir<0 ? px-(b*16+10) : 0);
  u16 pad = dir>0?BUTTON_RIGHT:dir<0?BUTTON_LEFT:0;
  if(gr){ bool go = inside || dist<=30; if(go && !(gPad&JUMP_MASK)) pad|=BUTTON_B; }
  else if(gPlayer.b.vy<0) pad|=BUTTON_B;
  s16 d; if(enemies_ahead(px,py,gPlayer.faceLeft?-1:1,110,&d) && (frames%14)==0) pad|=BUTTON_A;
  return pad;
}
static int commitWait=-1, commitDir=0;
u16 botPad; static int scenario;
static u8 lastScreen=255; static int playOrder[512], nPlays; static int titles, fails, deaths, completes, gameovers, ends;
static int selTest;
#define CHECK(c,msg) do{ if(!(c)){printf("  [FALHA] %s (frame %ld)\n",msg,frames);fails++;} else printf("  [ok] %s\n",msg);}while(0)

static void pulse(u16 b){ botPad = (frames&1)? b : 0; }

/* ---------------- planejador: usa a fisica REAL (player_update) para olhar a frente ---------------- */
static int goalX, goalY;
static void findGoal(void){ for(int l=0;l<NUM_LEVELS;l++) if(gLevels[l].w==lvW && gLevels[l].h==lvH){
   for(int i=0;i<gLevels[l].nSpawns;i++) if(gLevels[l].spawns[i].type==SP_GOAL){goalX=gLevels[l].spawns[i].x*16+8; goalY=(gLevels[l].spawns[i].y+1)*16;} } }
static long simulate(int dir,int s1,int s2,int H,u16 *first){
  Player saved=gPlayer; u16 sp=gPad, spp=gPadPrev; long cost, mind=1L<<40, minG=1L<<40; u16 prev=sp; int T=(lvH>14)?170:84;
  for(int f=0;f<T;f++){
    bool jb=(s1>=0&&f>=s1&&f<s1+H)||(s2>=0&&f>=s2&&f<s2+H);
    u16 pad=(dir>0?BUTTON_RIGHT:dir<0?BUTTON_LEFT:0)|(jb?BUTTON_B:0);
    if(f==0)*first=pad; gPadPrev=prev; gPad=pad; prev=pad; player_update();
    if(gPlayer.state==PS_DEAD||gPlayer.health<saved.health){cost=1000000;goto out;}
    { long x=gPlayer.b.x>>8, y=gPlayer.b.y>>8, dd=(lvH>14)?(20*labs(goalY-y)+labs(goalX-x)/8):(labs(goalX-x)+labs(goalY-y)/2); if(dd<mind)mind=dd; if(lvH>14 && gPlayer.b.ground && dd<minG) minG=dd; }
  }
  { long x=gPlayer.b.x>>8, y=gPlayer.b.y>>8; cost=(lvH>14)?(20*labs(goalY-y)+labs(goalX-x)/8):labs(goalX-x); if(mind<14) cost=mind; if(lvH>14 && minG<cost) cost=minG; }
out: gPlayer=saved; gPad=sp; gPadPrev=spp; return cost;
}
static void dump(void){ u16 f; for(int dir=1;dir>=-1;dir--){ long c=simulate(dir,-1,-1,40,&f); printf("   dir=%d sem pulo cost=%ld\n",dir,c); c=simulate(dir,0,-1,40,&f); printf("   dir=%d pulo0 cost=%ld first=%x\n",dir,c,f); c=simulate(dir,8,-1,40,&f); printf("   dir=%d pulo8 cost=%ld\n",dir,c);} 
  printf("   goal=%d,%d lvH=%d ground=%d coy=%d\n",goalX,goalY,lvH,gPlayer.b.ground,gPlayer.coyote);}

static u16 plan(void){ if(getenv("DUMP")&&lvW==120&&levelFrames==3000) dump();
  if(commitWait>=0){ u16 pad=(commitDir>0?BUTTON_RIGHT:commitDir<0?BUTTON_LEFT:0);
    if(!(gPlayer.b.ground||gPlayer.coyote>0) || gPlayer.state!=PS_NORMAL){ commitWait=-1; }
    else { if(commitWait==0){ commitWait=-1; return pad|BUTTON_B; } commitWait--; return pad; } }
  long best=1L<<60; u16 bestPad=BUTTON_RIGHT; int bestDir=1,bestS1=-1;
  bool canJump = gPlayer.b.ground || gPlayer.coyote>0;
  static const int starts[]={-1,0,4,8,12,16,20,26,32,40,52,64,76,88,100,112}, Hs[]={10,40}, gaps[]={-1,4,12,22};
  for(int dir=1;dir>=-1;dir--)
   for(int si=0; si<16; si++){ if(si>=10 && lvH<=14) break;
    if(si>1 && !canJump) break;
    if(si==1 && canJump && gPlayer.b.ground && (gPad&JUMP_MASK)) continue;   /* B ja pressionado no chao: precisa soltar antes de pular */                 /* no ar: so segurar (inicio 0) ou nao */
    for(int hi=0; hi<2; hi++){ if(si==0 && hi>0) break;
     for(int gi=0; gi<4; gi++){ if(si==0 && gi>0) break;
       int s1=starts[si]; int s2=(gi==0||s1<0)? -1 : (s1<0?0:s1)+Hs[hi]+gaps[gi];
       if(si==0 && gi>0) continue;
       if(s1<0 && gi>0) continue;
       u16 first; long c=simulate(dir,s1,s2,Hs[hi],&first);
       if(s1>0) c+=s1*((lvH>14)?2:12); if(s2>0) c+=s2/3;
       if(getenv("DUMP")&&lvW==120&&levelFrames==3000&&c<best) printf("   melhor: dir=%d s1=%d s2=%d H=%d cost=%ld first=%x\n",dir,s1,s2,Hs[hi],c,first);
       if(c<best){best=c;bestPad=first;bestDir=dir;bestS1=s1;}
     }}}
  if(canJump && bestS1>0){ commitWait=bestS1-1; commitDir=bestDir; }
  s16 d; s16 px=gPlayer.b.x>>8, py=gPlayer.b.y>>8;
  if(canJump && enemies_ahead(px,py,gPlayer.faceLeft?-1:1,46,&d) && lvH<=14) bestPad|=BUTTON_B;           /* pula/pisa no inimigo */
  if(enemies_ahead(px,py,gPlayer.faceLeft?-1:1,110,&d) && (frames%14)==0) bestPad|=BUTTON_A;               /* estrela */
  return bestPad;
}

static int atGoalHandled;
void SYS_doVBlankProcess(void){
  frames++;
  if(frames>900000){printf("TIMEOUT scenario %d (screen %d)\n",scenario,gScreen);exit(2);}
  if(gScreen!=lastScreen){
    lastScreen=gScreen; levelFrames=0;
    static const char*nm[]={"TITULO","SELECAO","INTRO","JOGO","PAUSA","FASE CONCLUIDA","GAME OVER","FINAL","CREDITOS","OPCOES FINAIS"};
    printf("  tela: %-15s lives=%d score=%u unlocked=%d lvW=%d\n",nm[gScreen],gGame.lives,(unsigned)gGame.score,gGame.unlocked,lvW);
    if(gScreen==SCR_TITLE) titles++;
    if(gScreen==SCR_PLAY){ playOrder[nPlays++]=lvW; }
    if(gScreen==SCR_COMPLETE) completes++;
    if(gScreen==SCR_GAMEOVER) gameovers++;
    if(gScreen==SCR_ENDING) ends++;
  }
  levelFrames++;
  switch(gScreen){
   case SCR_PLAY: {
     if(getenv("DUMP")&&lvW==120&&levelFrames==3000) printf("   [dbg] tela=%d pad=%x commitWait=%d state=%d y=%d\n",gScreen,botPad,commitWait,gPlayer.state,(int)(gPlayer.b.y>>8));
     { static int ps=-1; if(gPlayer.state!=ps){ if(gPlayer.state==PS_DEAD||gPlayer.state==PS_HURT||gPlayer.state==PS_WIN) printf("      evento estado=%d x=%d y=%d hp=%d vidas=%d\n",gPlayer.state,(int)(gPlayer.b.x>>8),(int)(gPlayer.b.y>>8),gPlayer.health,gGame.lives); ps=gPlayer.state; } }
     if(levelFrames==2) findGoal();
     { static int lastWinLv=-1; if(gPlayer.state==PS_WIN && lastWinLv!=lvW && getenv("CAMLOG")){ lastWinLv=lvW; printf("    bandeira alcancada (lvW=%d): camX=%d (max=%d) camY=%d (max=%d)\n",lvW,gCamX,lvW*16-320,gCamY,lvH*16-224>0?lvH*16-224:0);} }
     if(getenv("TRACE")&&levelFrames>15900&&levelFrames%40==0) printf("      f%ld x=%d y=%d vx=%d vy=%d gr=%d pad=%x st=%d cw=%d\n",levelFrames,(int)(gPlayer.b.x>>8),(int)(gPlayer.b.y>>8),gPlayer.b.vx,gPlayer.b.vy,gPlayer.b.ground,botPad,gPlayer.state,commitWait);
     /* invariantes: camera e jogador dentro do mapa */
     if(gCamX<0||gCamX>lvW*16-320||gCamY<0||gCamY>(lvH*16-224>0?lvH*16-224:0)){printf("  [FALHA] camera fora do limite %d,%d\n",gCamX,gCamY);fails++;exit(3);}
     { int px=gPlayer.b.x>>8; if(px<0||px>lvW*16){printf("  [FALHA] jogador fora do mapa x=%d\n",px);fails++;exit(3);} }
     if(levelFrames>16000){printf("  [dbg] levelFrames=%ld frames=%ld screen=%d\n",levelFrames,frames,gScreen);printf("  [FALHA] fase nao concluida em 16000 quadros (lvW=%d) x=%d y=%d lives=%d\n",lvW,(int)(gPlayer.b.x>>8),(int)(gPlayer.b.y>>8),gGame.lives);exit(4);}
     if(scenario==1||scenario==2){ botPad=BUTTON_RIGHT; static int lastLives=9; if(gGame.lives!=lastLives){ if(gGame.lives<lastLives&&lastLives!=9){deaths++;printf("    morreu (queda no buraco) -> vidas=%d, renasce x=%d\n",gGame.lives,(int)gPlayer.cpX/16);} lastLives=gGame.lives;} }
     else if(scenario==5){
        static int killed; static int before; static int armed;
        if(!killed && gPlayer.cpX>100 && lvW==100 && gPlayer.state==PS_NORMAL){ killed=1; before=gGame.lives; printf("    checkpoint ativo em x=%d: forcando morte\n",gPlayer.cpX/16); player_kill(); armed=1; }
        if(armed && gPlayer.state==PS_NORMAL && gPlayer.timer<3){ armed=0;
           CHECK(gGame.lives==before-1,"perdeu 1 vida ao morrer");
           CHECK(((gPlayer.b.x>>8)==gPlayer.cpX)&&((gPlayer.b.y>>8)==gPlayer.cpY),"renasceu exatamente no ultimo checkpoint");
           printf("\nRESULTADO checkpoint: %s\n",fails?"FALHOU":"OK"); exit(fails?1:0);}
        botPad=plan();
     }
     else { botPad=(lvH>14)?climb():plan(); if(getenv("DUMP")&&lvW==20&&levelFrames>=200&&levelFrames<206) printf("   frame %ld plan->%x gPad=%x prev=%x ground=%d jumping=%d\n",levelFrames,botPad,gPad,gPadPrev,gPlayer.b.ground,gPlayer.jumping); }
     break; }
   case SCR_TITLE: if(scenario==4){ static int st=0; st++; botPad=(st==3)?BUTTON_DOWN:(st==8)?BUTTON_START:0; } else pulse(BUTTON_START); break;
   case SCR_SELECT: { /* so a fase 1 deve estar liberada: DOWN x3 nao pode sair da fase 1 */
        static int st=0; st++; botPad=(st==4||st==8||st==12)?BUTTON_DOWN:(st==40)?BUTTON_START:0; break; }
   case SCR_GAMEOVER: { static int st; st=levelFrames; if(scenario==1) botPad=(st==40)?BUTTON_DOWN:(st==60)?BUTTON_START:0; else if(scenario==2) botPad=(st==60)?BUTTON_START:0; else pulse(BUTTON_START); break; }
   case SCR_ENDCHOICE: { int st=levelFrames; if(scenario==3) botPad=(st==40)?BUTTON_DOWN:(st==60)?BUTTON_START:0; else botPad=(st==40)?BUTTON_START:0; break; }
   default: pulse(BUTTON_START);
  }
  /* criterios de termino por cenario */
  if(scenario==0 && titles==2){
    printf("\nRESULTADO campanha completa:\n");
    int exp[5]={100,110,20,120,150}; int col[512],nc=0; for(int i=0;i<nPlays;i++) if(nc==0||col[nc-1]!=playOrder[i]) col[nc++]=playOrder[i]; bool order=(nc==5); for(int i=0;i<5&&order;i++) if(col[i]!=exp[i]) order=FALSE;
    CHECK(order,"as 5 fases foram jogadas em ordem (100,110,20,120,150 celulas)");
    CHECK(completes==4,"4 telas 'FASE CONCLUIDA' (fases 1-4) antes do final");
    CHECK(ends==1,"cena final apresentada uma vez");
    CHECK(gGame.unlocked==4,"fases 2..5 desbloqueadas ao concluir as anteriores");
    CHECK(titles==2,"retornou ao titulo apos os creditos");
    exit(fails?1:0);
  }
  if(scenario==1 && titles==2){ printf("\nRESULTADO game over -> voltar ao menu:\n"); CHECK(gameovers==1,"Game Over exibido");CHECK(deaths>=2,"vidas perdidas ao cair em buraco"); CHECK(1,"voltou ao titulo"); exit(fails?1:0);}
  if(scenario==2 && gameovers==1 && gScreen==SCR_PLAY && levelFrames>30){ printf("\nRESULTADO game over -> tentar novamente:\n"); CHECK(gGame.lives==3,"vidas restauradas para 3"); CHECK(nPlays==2&&playOrder[1]==100,"mesma fase 1 reiniciada"); exit(fails?1:0);}
  if(scenario==3 && ends==1 && gScreen==SCR_PLAY && lvW==100 && levelFrames>30 && nPlays>=6 && playOrder[nPlays-2]==150){ printf("\nRESULTADO jogar novamente:\n"); CHECK(gGame.lives==3&&gGame.score<2000&&gGame.unlocked==4,"nova campanha comecou na fase 1 com estado zerado"); exit(fails?1:0);}
  if(scenario==4 && gScreen==SCR_PLAY){ printf("\nRESULTADO selecao de fases:\n"); CHECK(lvW==100,"com so a fase 1 liberada, a selecao so permite a fase 1"); exit(fails?1:0);}
}
int main(int argc,char**argv){ scenario=argc>1?atoi(argv[1]):0; printf("== cenario %d ==\n",scenario); game_main(1); return 0; }

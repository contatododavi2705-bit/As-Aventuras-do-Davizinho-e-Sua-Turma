#include <stdint.h>
#include <stddef.h>
typedef uint8_t u8; typedef int8_t s8; typedef uint16_t u16; typedef int16_t s16; typedef uint32_t u32; typedef int32_t s32; typedef u8 bool;
#define TRUE 1
#define FALSE 0
#define BUTTON_UP 1
#define BUTTON_DOWN 2
#define BUTTON_LEFT 4
#define BUTTON_RIGHT 8
#define BUTTON_B 0x10
#define BUTTON_C 0x20
#define BUTTON_A 0x40
#define BUTTON_START 0x80
#define JOY_1 0
#define PAL0 0
#define PAL1 1
#define PAL2 2
#define PAL3 3
#define TILE_USER_INDEX 112
#define TILE_ATTR(p,pr,v,h) 0
#define TILE_ATTR_FULL(p,pr,v,h,i) (i)
typedef enum {BG_B,BG_A,WINDOW} VDPPlane;
typedef enum {CPU,DMA} TransferMethod;
typedef enum {HIDDEN,VISIBLE,AUTO_FAST} Vis;
typedef struct {u16 data[16];} Palette;
typedef struct {Palette *palette;} SpriteDefinition;
typedef struct {int x;} Sprite; typedef struct {int n;} TileSet; typedef struct {int n;} Image;
#define Z80_DRIVER_XGM 1
#define SOUND_PCM_CH2 2
u16 JOY_readJoypad(u16 j);
Sprite* SPR_addSprite(const SpriteDefinition*,s16,s16,u16); void SPR_releaseSprite(Sprite*); void SPR_setAnim(Sprite*,s16);
void SPR_setPosition(Sprite*,s16,s16); void SPR_setHFlip(Sprite*,bool); void SPR_setVisibility(Sprite*,Vis); void SPR_update(void); void SPR_reset(void); bool SPR_initEx(u16);
void Z80_loadDriver(u16,bool); void XGM_setPCM(u8,const u8*,u32); void XGM_startPlayPCM(u8,u8,u16); void XGM_startPlay(const u8*); void XGM_stopPlay(void); void XGM_pausePlay(void); void XGM_resumePlay(void);
void VDP_loadTileSet(const TileSet*,u16,TransferMethod); void VDP_setTileMapXY(VDPPlane,u16,u16,u16); void VDP_clearPlane(VDPPlane,bool);
void PAL_setPalette(u16,const u16*,TransferMethod); void PAL_setColor(u16,u16);
void VDP_setTextPlane(VDPPlane); void VDP_setWindowHPos(bool,u16); void VDP_setWindowVPos(bool,u16); void VDP_setEnable(bool);
void VDP_setHorizontalScroll(VDPPlane,s16); void VDP_setVerticalScroll(VDPPlane,s16);
void VDP_drawText(const char*,u16,u16); void VDP_clearText(u16,u16,u16); void uintToStr(u32,char*,s16);
bool VDP_drawImageEx(VDPPlane,const Image*,u16,u16,u16,bool,bool);
void SYS_doVBlankProcess(void); s16 sinFix16(s16); s16 cosFix16(s16);

extern const SpriteDefinition spr_davi, spr_enemies, spr_items, spr_goal, spr_turma;
extern const TileSet ts_terrain, ts_bg; extern const Image img_title;
extern const u8 mus_fase1[],mus_fase2[],mus_fase3[],mus_fase4[],mus_fase5[],mus_vitoria[],mus_gameover[];
extern const u8 sfx_jump[256],sfx_coin[256],sfx_hurt[256],sfx_stomp[256],sfx_star[256],sfx_oneup[256],sfx_check[256],sfx_goal[256],sfx_heart[256];
